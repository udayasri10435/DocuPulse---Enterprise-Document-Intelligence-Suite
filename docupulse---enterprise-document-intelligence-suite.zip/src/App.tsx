import React, { useState } from 'react';
import { Header } from './components/Header';
import { VerticalTabs } from './components/VerticalTabs';
import { DocumentViewer } from './components/DocumentViewer';
import { StructuredInspector } from './components/StructuredInspector';
import { DocumentQueue } from './components/DocumentQueue';
import { WorkflowRunner } from './components/WorkflowRunner';
import { DocumentUploadModal } from './components/DocumentUploadModal';
import { DocumentQADrawer } from './components/DocumentQADrawer';
import { AnalyticsView } from './components/AnalyticsView';
import { WorkflowsManager } from './components/WorkflowsManager';
import { SAMPLE_DOCUMENTS } from './data/sampleDocuments';
import { DocumentItem, ExtractedField, VerticalType } from './types/document';

export default function App() {
  const [documents, setDocuments] = useState<DocumentItem[]>(SAMPLE_DOCUMENTS);
  const [activeVertical, setActiveVertical] = useState<VerticalType>('legal');
  const [currentView, setCurrentView] = useState<'workspace' | 'queue' | 'workflows' | 'analytics'>('workspace');
  const [selectedDocId, setSelectedDocId] = useState<string>(SAMPLE_DOCUMENTS[0].id);
  const [selectedField, setSelectedField] = useState<ExtractedField | null>(null);

  // Modals and Drawers
  const [isUploadOpen, setIsUploadOpen] = useState<boolean>(false);
  const [isWorkflowRunnerOpen, setIsWorkflowRunnerOpen] = useState<boolean>(false);
  const [isQAOpen, setIsQAOpen] = useState<boolean>(false);
  const [isExecutingWorkflow, setIsExecutingWorkflow] = useState<boolean>(false);
  const [isBatchProcessing, setIsBatchProcessing] = useState<boolean>(false);

  // Active selected document
  const currentDoc = documents.find((d) => d.id === selectedDocId) || documents[0];

  // Document counts per vertical
  const documentCounts: Record<VerticalType, number> = {
    legal: documents.filter((d) => d.vertical === 'legal').length,
    insurance: documents.filter((d) => d.vertical === 'insurance').length,
    healthcare: documents.filter((d) => d.vertical === 'healthcare').length,
    finance: documents.filter((d) => d.vertical === 'finance').length
  };

  // Switch vertical and auto-select matching document
  const handleVerticalChange = (v: VerticalType) => {
    setActiveVertical(v);
    const matchingDoc = documents.find((d) => d.vertical === v);
    if (matchingDoc) {
      setSelectedDocId(matchingDoc.id);
      setSelectedField(null);
    }
  };

  // Select document and open workspace
  const handleSelectDocument = (doc: DocumentItem) => {
    setSelectedDocId(doc.id);
    setActiveVertical(doc.vertical);
    setSelectedField(null);
    setCurrentView('workspace');
  };

  // Human-in-the-loop field update
  const handleUpdateField = (
    fieldKey: string,
    newValue: any,
    status: 'verified' | 'modified' | 'flagged'
  ) => {
    setDocuments((prevDocs) =>
      prevDocs.map((doc) => {
        if (doc.id !== currentDoc.id) return doc;
        const updatedFields = doc.fields.map((f) =>
          f.key === fieldKey
            ? { ...f, value: newValue, displayValue: String(newValue), status }
            : f
        );
        return {
          ...doc,
          fields: updatedFields,
          status: 'in_review',
          auditTrail: [
            ...doc.auditTrail,
            {
              timestamp: new Date().toLocaleString(),
              user: 'Human Reviewer',
              action: `Field [${fieldKey}] ${status}`,
              details: `Set value to: ${String(newValue).substring(0, 40)}`
            }
          ]
        };
      })
    );
  };

  // Execute workflow via server API
  const handleExecuteWorkflow = async (workflowId: string, workflowName: string) => {
    if (!currentDoc) return;
    setIsExecutingWorkflow(true);

    try {
      const response = await fetch('/api/execute-workflow', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          workflowId,
          workflowName,
          vertical: currentDoc.vertical,
          documentTitle: currentDoc.title,
          fields: currentDoc.fields,
          redFlags: currentDoc.redFlags,
          verticalData: currentDoc.verticalData
        })
      });

      if (!response.ok) {
        throw new Error('Workflow execution call failed');
      }

      const data = await response.json();
      const execution = data.execution;

      // Update document state with completed execution
      setDocuments((prev) =>
        prev.map((d) => {
          if (d.id !== currentDoc.id) return d;
          return {
            ...d,
            status: execution.decision === 'auto_approved' ? 'approved' : 'flagged',
            workflows: [execution, ...d.workflows],
            auditTrail: [
              ...d.auditTrail,
              {
                timestamp: new Date().toLocaleString(),
                user: 'Workflow Automation Engine',
                action: `${workflowName} Finished`,
                details: `Outcome: ${execution.decision} — ${execution.decisionRationale}`
              }
            ]
          };
        })
      );
    } catch (err: any) {
      console.error('Workflow error:', err);
    } finally {
      setIsExecutingWorkflow(false);
    }
  };

  // Trigger workflow modal
  const handleOpenWorkflowModal = (workflowName: string) => {
    setIsWorkflowRunnerOpen(true);
    handleExecuteWorkflow('wf-trigger', workflowName);
  };

  // Batch process all documents
  const handleBatchProcess = async () => {
    setIsBatchProcessing(true);
    setTimeout(() => {
      setDocuments((prev) =>
        prev.map((doc) => ({
          ...doc,
          status: doc.redFlags.length > 0 ? 'flagged' : 'approved',
          confidenceScore: Math.max(doc.confidenceScore, 0.96)
        }))
      );
      setIsBatchProcessing(false);
    }, 1200);
  };

  // New Document Ingestion callback
  const handleIngestComplete = (newDoc: DocumentItem) => {
    setDocuments((prev) => [newDoc, ...prev]);
    setSelectedDocId(newDoc.id);
    setActiveVertical(newDoc.vertical);
    setSelectedField(null);
    setCurrentView('workspace');
  };

  // Delete Document
  const handleDeleteDocument = (docId: string) => {
    setDocuments((prev) => prev.filter((d) => d.id !== docId));
    if (selectedDocId === docId) {
      const remaining = documents.filter((d) => d.id !== docId);
      if (remaining.length > 0) {
        setSelectedDocId(remaining[0].id);
        setActiveVertical(remaining[0].vertical);
      }
    }
  };

  return (
    <div className="h-full flex flex-col bg-slate-950 text-slate-100 select-none">
      {/* 1. Header (Zone 1 Wordmark, Zone 2 Navigation, Zone 3 Actions) */}
      <Header
        currentView={currentView}
        onViewChange={setCurrentView}
        activeVertical={activeVertical}
        onVerticalChange={handleVerticalChange}
        onOpenUpload={() => setIsUploadOpen(true)}
        onOpenQA={() => setIsQAOpen(true)}
        documentCount={documents.length}
      />

      {/* 2. Vertical Sub-Navigation Tabs */}
      <VerticalTabs
        activeVertical={activeVertical}
        onSelect={handleVerticalChange}
        documentCounts={documentCounts}
      />

      {/* 3. Main Viewport Area */}
      <main className="flex-1 overflow-hidden relative flex">
        {/* VIEW 1: DUAL-PANE INSPECTOR WORKSPACE */}
        {currentView === 'workspace' && currentDoc && (
          <div className="flex-1 flex flex-col md:flex-row h-full overflow-hidden">
            {/* Left Pane: Document Viewer & Highlight Grounding */}
            <div className="w-full md:w-1/2 h-1/2 md:h-full overflow-hidden">
              <DocumentViewer
                document={currentDoc}
                selectedField={selectedField}
                onSelectField={setSelectedField}
              />
            </div>

            {/* Right Pane: Structured Extraction, Human-In-The-Loop Audit & Workflows */}
            <div className="w-full md:w-1/2 h-1/2 md:h-full overflow-hidden">
              <StructuredInspector
                document={currentDoc}
                selectedField={selectedField}
                onSelectField={setSelectedField}
                onUpdateField={handleUpdateField}
                onRunWorkflow={handleOpenWorkflowModal}
                isExecutingWorkflow={isExecutingWorkflow}
              />
            </div>
          </div>
        )}

        {/* VIEW 2: BATCH QUEUE */}
        {currentView === 'queue' && (
          <DocumentQueue
            documents={documents}
            activeVertical={activeVertical}
            onSelectDocument={handleSelectDocument}
            onRunWorkflow={(doc) => {
              setSelectedDocId(doc.id);
              setActiveVertical(doc.vertical);
              setIsWorkflowRunnerOpen(true);
              handleExecuteWorkflow('wf-queue', `${doc.vertical.toUpperCase()} Compliance Triage`);
            }}
            onDeleteDocument={handleDeleteDocument}
            onOpenUpload={() => setIsUploadOpen(true)}
            onBatchProcess={handleBatchProcess}
            isBatchProcessing={isBatchProcessing}
          />
        )}

        {/* VIEW 3: WORKFLOWS MANAGER */}
        {currentView === 'workflows' && (
          <WorkflowsManager
            documents={documents}
            activeVertical={activeVertical}
            onVerticalChange={handleVerticalChange}
            onTestWorkflow={(doc, workflowName) => {
              setSelectedDocId(doc.id);
              setActiveVertical(doc.vertical);
              setIsWorkflowRunnerOpen(true);
              handleExecuteWorkflow('wf-test', workflowName);
            }}
          />
        )}

        {/* VIEW 4: INTELLIGENCE METRICS */}
        {currentView === 'analytics' && (
          <AnalyticsView
            documents={documents}
            onSelectDocument={handleSelectDocument}
          />
        )}
      </main>

      {/* MODAL: WORKFLOW RUNNER */}
      {currentDoc && (
        <WorkflowRunner
          document={currentDoc}
          isOpen={isWorkflowRunnerOpen}
          onClose={() => setIsWorkflowRunnerOpen(false)}
          onExecute={handleExecuteWorkflow}
          isExecuting={isExecutingWorkflow}
        />
      )}

      {/* MODAL: DOCUMENT INGESTION / UPLOAD */}
      <DocumentUploadModal
        isOpen={isUploadOpen}
        onClose={() => setIsUploadOpen(false)}
        onIngestComplete={handleIngestComplete}
        defaultVertical={activeVertical}
      />

      {/* DRAWER: AD-HOC DOCUMENT Q&A */}
      {currentDoc && (
        <DocumentQADrawer
          document={currentDoc}
          isOpen={isQAOpen}
          onClose={() => setIsQAOpen(false)}
        />
      )}
    </div>
  );
}
