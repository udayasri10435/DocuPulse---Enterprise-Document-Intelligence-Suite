import React, { useState } from 'react';
import {
  FileText,
  Search,
  Filter,
  CheckCircle2,
  AlertTriangle,
  Play,
  Trash2,
  ExternalLink,
  Plus,
  Scale,
  ShieldCheck,
  HeartPulse,
  Receipt,
  Sparkles,
  ArrowUpDown
} from 'lucide-react';
import { DocumentItem, VerticalType } from '../types/document';
import { formatDate, getConfidenceColor } from '../utils/formatters';

interface DocumentQueueProps {
  documents: DocumentItem[];
  activeVertical: VerticalType;
  onSelectDocument: (doc: DocumentItem) => void;
  onRunWorkflow: (doc: DocumentItem) => void;
  onDeleteDocument: (docId: string) => void;
  onOpenUpload: () => void;
  onBatchProcess: () => void;
  isBatchProcessing?: boolean;
}

export const DocumentQueue: React.FC<DocumentQueueProps> = ({
  documents,
  activeVertical,
  onSelectDocument,
  onRunWorkflow,
  onDeleteDocument,
  onOpenUpload,
  onBatchProcess,
  isBatchProcessing = false
}) => {
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [verticalFilter, setVerticalFilter] = useState<string>(activeVertical);

  const getVerticalIcon = (v: VerticalType) => {
    switch (v) {
      case 'legal':
        return <Scale className="w-3.5 h-3.5 text-indigo-400" />;
      case 'insurance':
        return <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />;
      case 'healthcare':
        return <HeartPulse className="w-3.5 h-3.5 text-emerald-400" />;
      case 'finance':
        return <Receipt className="w-3.5 h-3.5 text-cyan-400" />;
    }
  };

  const filteredDocs = documents.filter((doc) => {
    if (verticalFilter !== 'all' && doc.vertical !== verticalFilter) return false;
    if (statusFilter !== 'all' && doc.status !== statusFilter) return false;
    if (
      searchQuery &&
      !doc.title.toLowerCase().includes(searchQuery.toLowerCase()) &&
      !doc.filename.toLowerCase().includes(searchQuery.toLowerCase()) &&
      !doc.documentType.toLowerCase().includes(searchQuery.toLowerCase())
    ) {
      return false;
    }
    return true;
  });

  return (
    <div className="flex flex-col h-full bg-slate-950 p-6 select-text overflow-hidden">
      {/* Top Controls Bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <h2 className="text-base font-semibold text-white">
            Document Ingestion & Batch Queue
          </h2>
          <p className="text-xs text-slate-400">
            Monitor incoming enterprise streams, extraction confidence, and automated compliance routing
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            disabled={isBatchProcessing}
            onClick={onBatchProcess}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-200 hover:text-white bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-lg transition-colors disabled:opacity-50"
          >
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <span>{isBatchProcessing ? 'Processing Queue...' : 'Batch Triage All'}</span>
          </button>

          <button
            onClick={onOpenUpload}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-lg transition-colors shadow-sm"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>+ Ingest Document</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="py-3 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2 flex-1 max-w-md">
          <div className="relative w-full">
            <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search documents by title, filename, or type..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-900 border border-slate-800 rounded-lg pl-9 pr-3 py-1.5 text-xs text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-cyan-500"
            />
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Vertical filter */}
          <select
            value={verticalFilter}
            onChange={(e) => setVerticalFilter(e.target.value)}
            className="bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-300 focus:outline-none focus:border-cyan-500"
          >
            <option value="all">All Verticals</option>
            <option value="legal">Legal Contracts</option>
            <option value="insurance">Insurance Claims</option>
            <option value="healthcare">Healthcare Clinical</option>
            <option value="finance">Finance Invoices</option>
          </select>

          {/* Status filter */}
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-300 focus:outline-none focus:border-cyan-500"
          >
            <option value="all">All Statuses</option>
            <option value="in_review">In Review</option>
            <option value="extracted">Extracted</option>
            <option value="approved">Auto-Approved</option>
            <option value="flagged">Flagged / Escalated</option>
          </select>
        </div>
      </div>

      {/* High-Density Data Table */}
      <div className="flex-1 overflow-y-auto border border-slate-800 rounded-lg bg-slate-950/80">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-900/90 text-slate-400 font-mono text-[11px] uppercase tracking-wider sticky top-0 border-b border-slate-800 z-10">
            <tr>
              <th className="py-2.5 px-4">Document Title & Filename</th>
              <th className="py-2.5 px-3">Vertical</th>
              <th className="py-2.5 px-3">Classification Type</th>
              <th className="py-2.5 px-3 text-center">Confidence</th>
              <th className="py-2.5 px-3">Risk Flags</th>
              <th className="py-2.5 px-3">Audit Status</th>
              <th className="py-2.5 px-3">Ingestion Date</th>
              <th className="py-2.5 px-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/80">
            {filteredDocs.length === 0 ? (
              <tr>
                <td colSpan={8} className="py-12 text-center text-slate-500 text-xs">
                  No documents match your query. Ingest a document or adjust filters.
                </td>
              </tr>
            ) : (
              filteredDocs.map((doc) => {
                const conf = getConfidenceColor(doc.confidenceScore);
                const hasFlags = doc.redFlags.length > 0;

                return (
                  <tr
                    key={doc.id}
                    onClick={() => onSelectDocument(doc)}
                    className="hover:bg-slate-900/60 cursor-pointer transition-colors group"
                  >
                    {/* Document Title */}
                    <td className="py-3 px-4 max-w-xs">
                      <div className="flex items-start gap-2.5">
                        <FileText className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                        <div className="min-w-0">
                          <div className="font-semibold text-slate-100 truncate group-hover:text-cyan-300 transition-colors">
                            {doc.title}
                          </div>
                          <div className="text-[11px] text-slate-500 font-mono truncate">
                            {doc.filename} · {doc.fileSize}
                          </div>
                        </div>
                      </div>
                    </td>

                    {/* Vertical */}
                    <td className="py-3 px-3 whitespace-nowrap">
                      <div className="flex items-center gap-1.5 font-medium text-slate-300 capitalize">
                        {getVerticalIcon(doc.vertical)}
                        <span>{doc.vertical}</span>
                      </div>
                    </td>

                    {/* Classification Type */}
                    <td className="py-3 px-3 text-slate-300 max-w-[180px] truncate" title={doc.documentType}>
                      {doc.documentType}
                    </td>

                    {/* Confidence Score */}
                    <td className="py-3 px-3 text-center">
                      <span
                        className={`inline-block font-mono text-[11px] px-2 py-0.5 rounded border tabular-nums ${conf.bg} ${conf.text} ${conf.border}`}
                      >
                        {(doc.confidenceScore * 100).toFixed(0)}%
                      </span>
                    </td>

                    {/* Risk Flags */}
                    <td className="py-3 px-3 whitespace-nowrap">
                      {hasFlags ? (
                        <span className="flex items-center gap-1 text-[11px] font-mono text-rose-400">
                          <AlertTriangle className="w-3.5 h-3.5" />
                          <span>{doc.redFlags.length} Flag(s)</span>
                        </span>
                      ) : (
                        <span className="text-[11px] font-mono text-slate-500">
                          Clean
                        </span>
                      )}
                    </td>

                    {/* Status */}
                    <td className="py-3 px-3 whitespace-nowrap">
                      <span className="capitalize text-slate-300 font-medium">
                        {doc.status.replace('_', ' ')}
                      </span>
                    </td>

                    {/* Ingestion Date */}
                    <td className="py-3 px-3 font-mono text-[11px] text-slate-400 whitespace-nowrap">
                      {formatDate(doc.uploadedAt)}
                    </td>

                    {/* Action buttons */}
                    <td className="py-3 px-4 text-right whitespace-nowrap" onClick={(e) => e.stopPropagation()}>
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => onSelectDocument(doc)}
                          className="px-2.5 py-1 text-[11px] bg-slate-800 hover:bg-slate-700 text-slate-200 rounded font-medium transition-colors"
                        >
                          Inspect
                        </button>

                        <button
                          onClick={() => onRunWorkflow(doc)}
                          className="p-1 text-slate-400 hover:text-cyan-400 rounded hover:bg-slate-800 transition-colors"
                          title="Execute Compliance Workflow"
                        >
                          <Play className="w-3.5 h-3.5" />
                        </button>

                        <button
                          onClick={() => onDeleteDocument(doc.id)}
                          className="p-1 text-slate-500 hover:text-rose-400 rounded hover:bg-slate-800 transition-colors"
                          title="Delete Document"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Queue footer stats */}
      <div className="pt-3 flex items-center justify-between text-xs text-slate-500 font-mono">
        <div>
          Displaying {filteredDocs.length} of {documents.length} enterprise documents
        </div>
        <div>
          Automated by Gemini 3.8 Flash Document OCR Engine
        </div>
      </div>
    </div>
  );
};
