import React, { useState, useRef, useEffect } from 'react';
import {
  FileText,
  Search,
  ZoomIn,
  ZoomOut,
  Maximize2,
  ChevronLeft,
  ChevronRight,
  Eye,
  CheckCircle2,
  AlertTriangle,
  ExternalLink,
  BookOpen
} from 'lucide-react';
import { DocumentItem, ExtractedField } from '../types/document';

interface DocumentViewerProps {
  document: DocumentItem;
  selectedField: ExtractedField | null;
  onSelectField: (field: ExtractedField | null) => void;
  activeHighlightText?: string;
}

export const DocumentViewer: React.FC<DocumentViewerProps> = ({
  document,
  selectedField,
  onSelectField,
  activeHighlightText
}) => {
  const [zoomLevel, setZoomLevel] = useState<number>(100);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [activeTab, setActiveTab] = useState<'formatted' | 'raw' | 'pdf'>('formatted');
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  // When selected field changes, scroll to grounded text
  useEffect(() => {
    if (selectedField?.grounding?.textExcerpt && scrollContainerRef.current) {
      const excerpt = selectedField.grounding.textExcerpt;
      const elements = scrollContainerRef.current.querySelectorAll('.highlight-target');
      for (const el of Array.from(elements)) {
        if (el.textContent?.toLowerCase().includes(excerpt.substring(0, 30).toLowerCase())) {
          el.scrollIntoView({ behavior: 'smooth', block: 'center' });
          break;
        }
      }
    }
  }, [selectedField]);

  // Clean lines for formatted reading
  const documentLines = document.rawText.split('\n');

  // Split into simulated pages (approx 35 lines per page)
  const linesPerPage = 38;
  const totalPages = Math.max(1, Math.ceil(documentLines.length / linesPerPage));
  const pageLines = documentLines.slice(
    (currentPage - 1) * linesPerPage,
    currentPage * linesPerPage
  );

  const targetExcerpt = activeHighlightText || selectedField?.grounding?.textExcerpt || '';

  const renderLineWithHighlights = (line: string, lineIndex: number) => {
    if (!line.trim()) {
      return <div key={lineIndex} className="h-4" />;
    }

    const isHeader =
      line === line.toUpperCase() && line.length > 5 && line.length < 80;
    const isSection =
      /^[0-9]+\.\s+[A-Z\s]+/.test(line) || /^[A-Z\s]{4,}:/.test(line);

    let contentNode: React.ReactNode = line;

    // Check if line contains the targeted excerpt
    if (targetExcerpt && line.toLowerCase().includes(targetExcerpt.substring(0, 25).toLowerCase())) {
      const lowerLine = line.toLowerCase();
      const lowerTarget = targetExcerpt.toLowerCase();
      const matchIndex = lowerLine.indexOf(lowerTarget.substring(0, 25));

      if (matchIndex !== -1) {
        const pre = line.substring(0, matchIndex);
        const match = line.substring(matchIndex, matchIndex + targetExcerpt.length);
        const post = line.substring(matchIndex + targetExcerpt.length);

        contentNode = (
          <span>
            {pre}
            <mark className="highlight-target bg-cyan-400/25 text-cyan-200 border-b-2 border-cyan-400 px-0.5 rounded transition-all duration-300 font-medium shadow-sm">
              {match || line}
            </mark>
            {post}
          </span>
        );
      }
    } else {
      // Check if line matches any extracted field's grounding
      const matchingField = document.fields.find(
        (f) =>
          f.grounding?.textExcerpt &&
          line.toLowerCase().includes(f.grounding.textExcerpt.substring(0, 20).toLowerCase())
      );

      if (matchingField) {
        contentNode = (
          <span
            onClick={() => onSelectField(matchingField)}
            className="cursor-pointer hover:bg-slate-800/80 px-1 -mx-1 rounded transition-colors group relative inline-block w-full"
            title={`Extracted Field: ${matchingField.label}`}
          >
            {line}
            <span className="opacity-0 group-hover:opacity-100 transition-opacity ml-2 inline-flex items-center text-[10px] text-cyan-400 font-mono">
              [Field: {matchingField.label}]
            </span>
          </span>
        );
      }
    }

    return (
      <div
        key={lineIndex}
        className={`flex items-start text-xs leading-relaxed py-0.5 transition-colors ${
          isHeader
            ? 'font-bold text-slate-100 tracking-wide text-sm mt-3 mb-1.5'
            : isSection
            ? 'font-semibold text-cyan-300 mt-2 mb-1'
            : 'text-slate-300'
        }`}
      >
        <span className="w-10 select-none text-[10px] font-mono tabular-nums text-slate-600 shrink-0 text-right pr-3 pt-0.5">
          {(currentPage - 1) * linesPerPage + lineIndex + 1}
        </span>
        <div className="flex-1 font-mono">{contentNode}</div>
      </div>
    );
  };

  return (
    <div className="flex flex-col h-full bg-slate-900/60 border-r border-slate-800 select-text overflow-hidden">
      {/* Top Document Controls Bar */}
      <div className="h-11 px-4 border-b border-slate-800/80 bg-slate-950/80 flex items-center justify-between gap-3 shrink-0">
        <div className="flex items-center gap-2 min-w-0">
          <FileText className="w-4 h-4 text-cyan-400 shrink-0" />
          <span className="text-xs font-medium text-slate-200 truncate" title={document.filename}>
            {document.filename}
          </span>
          <span className="text-[10px] font-mono text-slate-500 shrink-0 hidden sm:inline">
            · {document.fileSize}
          </span>
        </div>

        {/* View mode toggle & Page controls */}
        <div className="flex items-center gap-2">
          {/* Zoom controls */}
          <div className="hidden md:flex items-center gap-1 bg-slate-900 rounded border border-slate-800 px-1">
            <button
              onClick={() => setZoomLevel((z) => Math.max(75, z - 10))}
              className="p-1 text-slate-400 hover:text-white transition-colors"
              title="Zoom Out"
            >
              <ZoomOut className="w-3 h-3" />
            </button>
            <span className="text-[10px] font-mono tabular-nums text-slate-400 w-8 text-center">
              {zoomLevel}%
            </span>
            <button
              onClick={() => setZoomLevel((z) => Math.min(150, z + 10))}
              className="p-1 text-slate-400 hover:text-white transition-colors"
              title="Zoom In"
            >
              <ZoomIn className="w-3 h-3" />
            </button>
          </div>

          {/* Page Navigator */}
          <div className="flex items-center gap-1 bg-slate-900 rounded border border-slate-800 px-1 py-0.5">
            <button
              disabled={currentPage <= 1}
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              className="p-0.5 text-slate-400 hover:text-white disabled:opacity-30 transition-opacity"
            >
              <ChevronLeft className="w-3.5 h-3.5" />
            </button>
            <span className="text-[11px] font-mono tabular-nums text-slate-300 px-1">
              Page {currentPage} of {totalPages}
            </span>
            <button
              disabled={currentPage >= totalPages}
              onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              className="p-0.5 text-slate-400 hover:text-white disabled:opacity-30 transition-opacity"
            >
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Selected Field Grounding Notification Bar */}
      {selectedField && (
        <div className="px-4 py-2 bg-cyan-950/40 border-b border-cyan-800/40 flex items-center justify-between gap-3 text-xs shrink-0 animate-fadeIn">
          <div className="flex items-center gap-2 min-w-0">
            <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse shrink-0" />
            <span className="text-cyan-300 font-medium truncate">
              Inspecting Field: <strong className="text-white">{selectedField.label}</strong>
            </span>
            {selectedField.grounding && (
              <span className="text-[11px] font-mono text-cyan-400/80 shrink-0">
                (Page {selectedField.grounding.pageNumber})
              </span>
            )}
          </div>
          <button
            onClick={() => onSelectField(null)}
            className="text-[11px] text-slate-400 hover:text-white px-2 py-0.5 rounded hover:bg-slate-800 transition-colors"
          >
            Clear Focus
          </button>
        </div>
      )}

      {/* Document Content Viewport */}
      <div
        ref={scrollContainerRef}
        className="flex-1 overflow-y-auto p-6 bg-slate-950 relative"
      >
        <div
          style={{ transform: `scale(${zoomLevel / 100})`, transformOrigin: 'top center' }}
          className="transition-transform duration-150 max-w-3xl mx-auto bg-slate-900/90 border border-slate-800 rounded-lg p-8 shadow-xl shadow-black/40 min-h-[680px]"
        >
          {/* Simulated Paper Header */}
          <div className="border-b border-slate-800 pb-4 mb-6 flex items-center justify-between text-[11px] text-slate-500 font-mono uppercase tracking-wider">
            <span>DOCUPULSE OPTICAL AUDIT VIEW</span>
            <span>PAGE {currentPage} OF {totalPages}</span>
          </div>

          {/* Lines */}
          <div className="space-y-0.5">
            {pageLines.map((line, index) => renderLineWithHighlights(line, index))}
          </div>

          {/* Simulated Paper Footer */}
          <div className="border-t border-slate-800/80 pt-4 mt-8 flex items-center justify-between text-[10px] text-slate-600 font-mono">
            <span>CONFIDENTIAL & PROPRIETARY</span>
            <span>VERIFIED BY GEMINI 3.8 FLASH OCR</span>
          </div>
        </div>
      </div>
    </div>
  );
};
