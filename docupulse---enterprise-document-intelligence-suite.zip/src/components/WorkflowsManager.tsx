import React, { useState } from 'react';
import {
  Workflow,
  CheckCircle2,
  AlertCircle,
  Play,
  Settings2,
  Sliders,
  Scale,
  ShieldCheck,
  HeartPulse,
  Receipt,
  Sparkles,
  ArrowRight,
  Code
} from 'lucide-react';
import { DocumentItem, VerticalType } from '../types/document';
import { VERTICAL_CONFIGS } from '../data/verticalConfigs';

interface WorkflowsManagerProps {
  documents: DocumentItem[];
  activeVertical: VerticalType;
  onVerticalChange: (v: VerticalType) => void;
  onTestWorkflow: (doc: DocumentItem, workflowName: string) => void;
}

export const WorkflowsManager: React.FC<WorkflowsManagerProps> = ({
  documents,
  activeVertical,
  onVerticalChange,
  onTestWorkflow
}) => {
  const [selectedWorkflowId, setSelectedWorkflowId] = useState<string>('legal-wf-1');
  const [testDocumentId, setTestDocumentId] = useState<string>(
    documents.find((d) => d.vertical === activeVertical)?.id || documents[0]?.id || ''
  );

  const verticalConfig = VERTICAL_CONFIGS[activeVertical];
  const verticalDocs = documents.filter((d) => d.vertical === activeVertical);
  const selectedDoc = documents.find((d) => d.id === testDocumentId) || verticalDocs[0] || documents[0];

  return (
    <div className="flex-1 overflow-y-auto bg-slate-950 p-6 space-y-6 select-text">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <h2 className="text-base font-semibold text-white">
            Enterprise Compliance & Workflow Automation Engine
          </h2>
          <p className="text-xs text-slate-400">
            Define programmatic rule logic, risk triggers, and downstream integrations for {verticalConfig.name}
          </p>
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Workflows List */}
        <div className="space-y-3">
          <div className="text-xs font-semibold text-slate-300 uppercase tracking-wider font-mono">
            Active Rules & Trigger Policies
          </div>

          <div className="space-y-2.5">
            {verticalConfig.standardWorkflows.map((wf) => {
              const isSelected = selectedWorkflowId === wf.id;
              return (
                <div
                  key={wf.id}
                  onClick={() => setSelectedWorkflowId(wf.id)}
                  className={`p-4 rounded-lg border text-xs cursor-pointer transition-all ${
                    isSelected
                      ? 'border-cyan-500 bg-cyan-950/20 shadow-md shadow-cyan-950/20'
                      : 'border-slate-800 bg-slate-900/60 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between font-semibold text-slate-100">
                    <span>{wf.name}</span>
                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                      Active
                    </span>
                  </div>

                  <p className="text-slate-400 text-xs mt-1.5 leading-relaxed">
                    {wf.description}
                  </p>

                  <div className="mt-3 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
                    <span className="font-mono text-cyan-400 truncate max-w-[200px]" title={wf.trigger}>
                      {wf.trigger}
                    </span>
                    <span className="text-slate-500 font-mono">ID: {wf.id}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Center & Right Column: Workflow Detail & Interactive Simulation */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-sm font-semibold text-white">
                  Workflow Execution Simulation & Rule Inspection
                </h3>
                <span className="text-xs text-slate-400">
                  Test condition evaluation against actual ingested documents
                </span>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-400">Target Document:</span>
                <select
                  value={testDocumentId}
                  onChange={(e) => setTestDocumentId(e.target.value)}
                  className="bg-slate-950 border border-slate-800 rounded px-2.5 py-1 text-xs text-slate-200 focus:outline-none focus:border-cyan-500 max-w-[220px] truncate"
                >
                  {documents.map((d) => (
                    <option key={d.id} value={d.id}>
                      {d.title} ({d.vertical})
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Architecture Steps Breakdown */}
            <div className="space-y-3">
              <div className="text-xs font-mono uppercase text-slate-400 tracking-wider">
                Pipeline Lifecycle Stages
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div className="bg-slate-950 p-3.5 rounded border border-slate-800 space-y-1.5 text-xs">
                  <div className="flex items-center gap-2 text-cyan-400 font-mono font-semibold">
                    <span>01</span>
                    <span>Ingestion & OCR</span>
                  </div>
                  <p className="text-slate-400 text-[11px] leading-relaxed">
                    Gemini 3.8 Flash extracts optical text, entities, and line-item coordinates with confidence scores.
                  </p>
                </div>

                <div className="bg-slate-950 p-3.5 rounded border border-slate-800 space-y-1.5 text-xs">
                  <div className="flex items-center gap-2 text-amber-400 font-mono font-semibold">
                    <span>02</span>
                    <span>Rule Evaluation</span>
                  </div>
                  <p className="text-slate-400 text-[11px] leading-relaxed">
                    Evaluates multi-condition business logic (thresholds, non-competes, fraud score, PO variance).
                  </p>
                </div>

                <div className="bg-slate-950 p-3.5 rounded border border-slate-800 space-y-1.5 text-xs">
                  <div className="flex items-center gap-2 text-emerald-400 font-mono font-semibold">
                    <span>03</span>
                    <span>Action Dispatch</span>
                  </div>
                  <p className="text-slate-400 text-[11px] leading-relaxed">
                    Dispatches webhooks to DocuSign, Ironclad CLM, Guidewire ClaimCenter, Epic FHIR, or NetSuite ERP.
                  </p>
                </div>
              </div>
            </div>

            {/* Test Trigger Button */}
            {selectedDoc && (
              <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
                <div className="text-xs text-slate-400">
                  Ready to test with <strong className="text-slate-200">{selectedDoc.title}</strong>
                </div>

                <button
                  onClick={() => {
                    const currentWf = verticalConfig.standardWorkflows.find((w) => w.id === selectedWorkflowId);
                    onTestWorkflow(selectedDoc, currentWf?.name || 'Compliance Workflow');
                  }}
                  className="flex items-center gap-1.5 px-4 py-2 bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-bold text-xs rounded-lg transition-colors shadow-sm"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>Execute Test Simulation</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
