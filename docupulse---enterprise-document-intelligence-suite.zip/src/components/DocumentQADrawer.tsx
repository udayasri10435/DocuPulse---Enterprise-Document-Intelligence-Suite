import React, { useState } from 'react';
import {
  X,
  Send,
  HelpCircle,
  Sparkles,
  Bot,
  User,
  Quote,
  Loader2,
  FileText
} from 'lucide-react';
import { DocumentItem } from '../types/document';

interface DocumentQADrawerProps {
  document: DocumentItem;
  isOpen: boolean;
  onClose: () => void;
}

interface Message {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
}

export const DocumentQADrawer: React.FC<DocumentQADrawerProps> = ({
  document,
  isOpen,
  onClose
}) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'init-1',
      sender: 'assistant',
      text: `Hello! I have indexed **"${document.title}"** (${document.documentType}). Ask any question regarding clauses, liabilities, codes, loss calculations, or compliance rules.`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [inputQuestion, setInputQuestion] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);

  if (!isOpen) return null;

  const handleSend = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputQuestion.trim() || isLoading) return;

    const userQ = inputQuestion.trim();
    const userMsg: Message = {
      id: `u-${Date.now()}`,
      sender: 'user',
      text: userQ,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputQuestion('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/document-qa', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          documentText: document.rawText,
          question: userQ,
          vertical: document.vertical
        })
      });

      if (!response.ok) {
        throw new Error('Failed to query document');
      }

      const data = await response.json();
      const assistantMsg: Message = {
        id: `a-${Date.now()}`,
        sender: 'assistant',
        text: data.answer || 'No answer available.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setMessages((prev) => [...prev, assistantMsg]);
    } catch (err: any) {
      setMessages((prev) => [
        ...prev,
        {
          id: `err-${Date.now()}`,
          sender: 'assistant',
          text: `Error retrieving answer: ${err.message || 'Please try again.'}`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const sampleQuestions: Record<string, string[]> = {
    legal: [
      'What is the aggregate liability ceiling and are there any carve-outs?',
      'What is the governing law and what notice is required for auto-renewal?',
      'Does the provider indemnify against patent infringement?'
    ],
    insurance: [
      'What caused the accident and what is the police citation status?',
      'Are the cargo spoilage damages recoverable via subrogation?',
      'What is the policy deductible and total claim amount?'
    ],
    healthcare: [
      'Does the patient meet NCCN Category 1 criteria for Keytruda?',
      'What are the primary ICD-10 and HCPCS billing codes?',
      'Why is expedited 24-hour prior authorization requested?'
    ],
    finance: [
      'Does the invoice amount match PO-882104-GLOBAL exactly?',
      'What are the payment terms and when is payment due?',
      'What is the state sales tax breakdown on line items?'
    ]
  };

  const currentSuggested = sampleQuestions[document.vertical] || sampleQuestions.legal;

  return (
    <div className="fixed inset-y-0 right-0 z-50 w-full sm:w-[440px] bg-slate-900 border-l border-slate-800 shadow-2xl flex flex-col animate-slideLeft">
      {/* Header */}
      <div className="h-14 px-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/90 shrink-0">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
            <Sparkles className="w-3.5 h-3.5" />
          </div>
          <div>
            <h3 className="text-xs font-semibold text-white">
              Document Audit Q&A
            </h3>
            <span className="text-[10px] text-slate-400 truncate max-w-[240px] block">
              Auditing: {document.title}
            </span>
          </div>
        </div>

        <button
          onClick={onClose}
          className="text-slate-400 hover:text-white p-1 rounded hover:bg-slate-800 transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Suggested Questions */}
      <div className="px-4 py-2 bg-slate-950/60 border-b border-slate-800/60 text-xs shrink-0">
        <div className="text-[10px] font-mono text-slate-500 uppercase tracking-wider mb-1.5">
          Auditor Quick Questions
        </div>
        <div className="flex flex-wrap gap-1.5">
          {currentSuggested.map((q, idx) => (
            <button
              key={idx}
              onClick={() => {
                setInputQuestion(q);
              }}
              className="text-[11px] text-slate-300 hover:text-cyan-300 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded px-2 py-1 text-left transition-colors truncate max-w-full"
            >
              "{q}"
            </button>
          ))}
        </div>
      </div>

      {/* Chat Messages Body */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3.5 text-xs">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex items-start gap-2.5 ${
              msg.sender === 'user' ? 'justify-end' : 'justify-start'
            }`}
          >
            {msg.sender === 'assistant' && (
              <div className="w-6 h-6 rounded bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 shrink-0 mt-0.5">
                <Bot className="w-3.5 h-3.5" />
              </div>
            )}

            <div
              className={`max-w-[85%] rounded-lg p-3 text-xs leading-relaxed space-y-1 ${
                msg.sender === 'user'
                  ? 'bg-cyan-500 text-slate-950 font-medium'
                  : 'bg-slate-950 border border-slate-800 text-slate-200'
              }`}
            >
              <div className="whitespace-pre-wrap">{msg.text}</div>
              <div
                className={`text-[9px] font-mono tabular-nums text-right ${
                  msg.sender === 'user' ? 'text-slate-800' : 'text-slate-500'
                }`}
              >
                {msg.timestamp}
              </div>
            </div>

            {msg.sender === 'user' && (
              <div className="w-6 h-6 rounded bg-slate-800 flex items-center justify-center text-slate-300 shrink-0 mt-0.5">
                <User className="w-3.5 h-3.5" />
              </div>
            )}
          </div>
        ))}

        {isLoading && (
          <div className="flex items-center gap-2 text-xs text-cyan-400 p-2 bg-slate-950 rounded border border-slate-800/80 animate-pulse">
            <Loader2 className="w-3.5 h-3.5 animate-spin" />
            <span>Gemini 3.8 Flash analyzing document clauses...</span>
          </div>
        )}
      </div>

      {/* Input Box */}
      <form onSubmit={handleSend} className="p-3 border-t border-slate-800 bg-slate-950 shrink-0">
        <div className="flex items-center gap-2">
          <input
            type="text"
            placeholder="Ask a question about this document..."
            value={inputQuestion}
            onChange={(e) => setInputQuestion(e.target.value)}
            disabled={isLoading}
            className="flex-1 bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-cyan-500 disabled:opacity-50"
          />
          <button
            type="submit"
            disabled={!inputQuestion.trim() || isLoading}
            className="p-2 bg-cyan-400 hover:bg-cyan-300 text-slate-950 rounded-lg transition-colors disabled:opacity-40"
          >
            <Send className="w-3.5 h-3.5" />
          </button>
        </div>
      </form>
    </div>
  );
};
