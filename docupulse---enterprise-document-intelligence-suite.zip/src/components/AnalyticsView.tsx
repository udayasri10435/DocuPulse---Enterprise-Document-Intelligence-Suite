import React from 'react';
import {
  BarChart3,
  TrendingUp,
  ShieldAlert,
  Zap,
  CheckCircle2,
  FileText,
  Clock,
  ArrowUpRight,
  Scale,
  ShieldCheck,
  HeartPulse,
  Receipt
} from 'lucide-react';
import { DocumentItem, VerticalType } from '../types/document';

interface AnalyticsViewProps {
  documents: DocumentItem[];
  onSelectDocument: (doc: DocumentItem) => void;
}

export const AnalyticsView: React.FC<AnalyticsViewProps> = ({
  documents,
  onSelectDocument
}) => {
  const totalDocs = documents.length;
  const avgConfidence = totalDocs > 0
    ? (documents.reduce((acc, d) => acc + d.confidenceScore, 0) / totalDocs) * 100
    : 96.2;

  const stpEligibleDocs = documents.filter(
    (d) => d.status === 'approved' || d.confidenceScore >= 0.95
  ).length;
  const stpRate = totalDocs > 0 ? (stpEligibleDocs / totalDocs) * 100 : 88.4;

  const flaggedDocs = documents.filter((d) => d.redFlags.length > 0);

  const verticalBreakdown: Record<VerticalType, number> = {
    legal: documents.filter((d) => d.vertical === 'legal').length,
    insurance: documents.filter((d) => d.vertical === 'insurance').length,
    healthcare: documents.filter((d) => d.vertical === 'healthcare').length,
    finance: documents.filter((d) => d.vertical === 'finance').length
  };

  return (
    <div className="flex-1 overflow-y-auto bg-slate-950 p-6 space-y-6 select-text">
      {/* Header */}
      <div>
        <h2 className="text-base font-semibold text-white">
          Document Intelligence Metrics & Operational Performance
        </h2>
        <p className="text-xs text-slate-400">
          Real-time metrics on Straight-Through Processing (STP), field precision, and cross-vertical policy compliance
        </p>
      </div>

      {/* Top 4 KPI Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* KPI 1 */}
        <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-4 space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Straight-Through Rate (STP)</span>
            <Zap className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-white tabular-nums">
            {stpRate.toFixed(1)}%
          </div>
          <div className="text-[11px] text-emerald-400 flex items-center gap-1 font-mono">
            <TrendingUp className="w-3 h-3" />
            <span>+14.2% vs human-only manual data entry</span>
          </div>
        </div>

        {/* KPI 2 */}
        <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-4 space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Mean Extraction Confidence</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-white tabular-nums">
            {avgConfidence.toFixed(1)}%
          </div>
          <div className="text-[11px] text-slate-400 font-mono">
            Optical OCR & typed schema grounding
          </div>
        </div>

        {/* KPI 3 */}
        <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-4 space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Critical Red Flags Triage</span>
            <ShieldAlert className="w-4 h-4 text-rose-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-white tabular-nums">
            {flaggedDocs.length}
          </div>
          <div className="text-[11px] text-rose-400 font-mono">
            Escalated to Counsel / SIU / Medical Review
          </div>
        </div>

        {/* KPI 4 */}
        <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-4 space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Average Ingestion Latency</span>
            <Clock className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-white tabular-nums">
            1.24s
          </div>
          <div className="text-[11px] text-slate-400 font-mono">
            Multi-page contract & claim extraction
          </div>
        </div>
      </div>

      {/* Vertical Pipeline Distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left: Vertical Breakdown Card */}
        <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-5 space-y-4">
          <div className="flex items-center justify-between text-xs font-semibold text-slate-200">
            <span className="uppercase tracking-wider font-mono">
              Workload by Industry Vertical
            </span>
            <span className="text-slate-400 font-mono">{totalDocs} Documents Total</span>
          </div>

          <div className="space-y-3 text-xs">
            {/* Legal */}
            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-1.5 text-slate-300">
                  <Scale className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Legal & Contracts</span>
                </span>
                <span className="font-mono tabular-nums text-slate-400">
                  {verticalBreakdown.legal} ({((verticalBreakdown.legal / (totalDocs || 1)) * 100).toFixed(0)}%)
                </span>
              </div>
              <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-800">
                <div
                  className="bg-indigo-500 h-full rounded-full transition-all"
                  style={{ width: `${(verticalBreakdown.legal / (totalDocs || 1)) * 100}%` }}
                />
              </div>
            </div>

            {/* Insurance */}
            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-1.5 text-slate-300">
                  <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
                  <span>Insurance Claims (ACORD/FNOL)</span>
                </span>
                <span className="font-mono tabular-nums text-slate-400">
                  {verticalBreakdown.insurance} ({((verticalBreakdown.insurance / (totalDocs || 1)) * 100).toFixed(0)}%)
                </span>
              </div>
              <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-800">
                <div
                  className="bg-amber-500 h-full rounded-full transition-all"
                  style={{ width: `${(verticalBreakdown.insurance / (totalDocs || 1)) * 100}%` }}
                />
              </div>
            </div>

            {/* Healthcare */}
            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-1.5 text-slate-300">
                  <HeartPulse className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Healthcare Clinical & Prior-Auth</span>
                </span>
                <span className="font-mono tabular-nums text-slate-400">
                  {verticalBreakdown.healthcare} ({((verticalBreakdown.healthcare / (totalDocs || 1)) * 100).toFixed(0)}%)
                </span>
              </div>
              <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-800">
                <div
                  className="bg-emerald-500 h-full rounded-full transition-all"
                  style={{ width: `${(verticalBreakdown.healthcare / (totalDocs || 1)) * 100}%` }}
                />
              </div>
            </div>

            {/* Finance */}
            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-1.5 text-slate-300">
                  <Receipt className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Finance & AP Invoices</span>
                </span>
                <span className="font-mono tabular-nums text-slate-400">
                  {verticalBreakdown.finance} ({((verticalBreakdown.finance / (totalDocs || 1)) * 100).toFixed(0)}%)
                </span>
              </div>
              <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-800">
                <div
                  className="bg-cyan-500 h-full rounded-full transition-all"
                  style={{ width: `${(verticalBreakdown.finance / (totalDocs || 1)) * 100}%` }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Right: Flagged Documents Escalation List */}
        <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-5 space-y-3">
          <div className="flex items-center justify-between text-xs font-semibold text-slate-200">
            <span className="uppercase tracking-wider font-mono">
              High-Exposure Documents Awaiting Review
            </span>
            <span className="text-rose-400 font-mono text-[11px]">
              {flaggedDocs.length} Pending Actions
            </span>
          </div>

          <div className="space-y-2 text-xs">
            {flaggedDocs.length === 0 ? (
              <div className="text-slate-500 text-center py-6">
                All documents cleared compliance checks with zero critical red flags.
              </div>
            ) : (
              flaggedDocs.map((doc) => (
                <div
                  key={doc.id}
                  onClick={() => onSelectDocument(doc)}
                  className="p-3 bg-slate-950 rounded border border-slate-800/80 hover:border-cyan-500/60 cursor-pointer transition-colors space-y-1"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-slate-200 truncate max-w-xs">
                      {doc.title}
                    </span>
                    <span className="text-[10px] font-mono text-rose-400 bg-rose-500/10 px-1.5 py-0.5 rounded border border-rose-500/30">
                      {doc.redFlags.length} Flag(s)
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-400 truncate">
                    {doc.redFlags[0]?.title} — {doc.redFlags[0]?.description}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
