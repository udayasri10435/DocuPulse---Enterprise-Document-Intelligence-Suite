import React, { useState } from 'react';
import {
  Check,
  AlertTriangle,
  Edit2,
  Copy,
  ExternalLink,
  ChevronDown,
  ChevronUp,
  ShieldAlert,
  Sparkles,
  Play,
  FileCheck,
  Download,
  AlertCircle,
  Tag,
  RefreshCw,
  Plus
} from 'lucide-react';
import { DocumentItem, ExtractedField, RedFlagAlert, VerticalType } from '../types/document';
import { getConfidenceColor, getSeverityBadge, formatCurrency } from '../utils/formatters';

interface StructuredInspectorProps {
  document: DocumentItem;
  selectedField: ExtractedField | null;
  onSelectField: (field: ExtractedField | null) => void;
  onUpdateField: (fieldKey: string, newValue: any, status: 'verified' | 'modified' | 'flagged') => void;
  onRunWorkflow: (workflowName: string) => void;
  isExecutingWorkflow?: boolean;
}

export const StructuredInspector: React.FC<StructuredInspectorProps> = ({
  document,
  selectedField,
  onSelectField,
  onUpdateField,
  onRunWorkflow,
  isExecutingWorkflow = false
}) => {
  const [activeTab, setActiveTab] = useState<'fields' | 'flags' | 'vertical_view' | 'json'>('fields');
  const [editingKey, setEditingKey] = useState<string | null>(null);
  const [editValue, setEditValue] = useState<string>('');
  const [copied, setCopied] = useState<boolean>(false);

  const startEdit = (field: ExtractedField) => {
    setEditingKey(field.key);
    setEditValue(typeof field.value === 'object' ? JSON.stringify(field.value) : String(field.value));
  };

  const saveEdit = (fieldKey: string) => {
    onUpdateField(fieldKey, editValue, 'modified');
    setEditingKey(null);
  };

  const cancelEdit = () => {
    setEditingKey(null);
    setEditValue('');
  };

  const handleCopyJson = () => {
    const payload = {
      id: document.id,
      title: document.title,
      vertical: document.vertical,
      fields: document.fields.reduce((acc, f) => ({ ...acc, [f.key]: f.value }), {}),
      redFlags: document.redFlags,
      verticalData: document.verticalData
    };
    navigator.clipboard.writeText(JSON.stringify(payload, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="flex flex-col h-full bg-slate-950 select-text overflow-hidden">
      {/* Top Inspector Navigation Bar */}
      <div className="h-11 px-4 border-b border-slate-800/80 bg-slate-950 flex items-center justify-between gap-3 shrink-0">
        <div className="flex items-center gap-1 bg-slate-900 p-0.5 rounded-lg border border-slate-800">
          <button
            onClick={() => setActiveTab('fields')}
            className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
              activeTab === 'fields'
                ? 'bg-slate-800 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Structured Schema ({document.fields.length})
          </button>

          <button
            onClick={() => setActiveTab('flags')}
            className={`flex items-center gap-1.5 px-3 py-1 text-xs font-medium rounded-md transition-colors ${
              activeTab === 'flags'
                ? 'bg-slate-800 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <span>Risk Red Flags</span>
            {document.redFlags.length > 0 && (
              <span className="text-[10px] font-mono font-semibold px-1 rounded bg-rose-500/20 text-rose-300 border border-rose-500/30">
                {document.redFlags.length}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('vertical_view')}
            className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
              activeTab === 'vertical_view'
                ? 'bg-slate-800 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {document.vertical === 'legal' && 'Contract Overview'}
            {document.vertical === 'insurance' && 'Claims & Line Items'}
            {document.vertical === 'healthcare' && 'Clinical Coding & Prior-Auth'}
            {document.vertical === 'finance' && '3-Way PO Match'}
          </button>

          <button
            onClick={() => setActiveTab('json')}
            className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
              activeTab === 'json'
                ? 'bg-slate-800 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            JSON Tree
          </button>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopyJson}
            className="flex items-center gap-1 px-2.5 py-1 text-[11px] font-medium text-slate-300 hover:text-white bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded transition-colors"
            title="Copy structured extraction JSON"
          >
            <Copy className="w-3 h-3 text-cyan-400" />
            <span>{copied ? 'Copied' : 'Export JSON'}</span>
          </button>
        </div>
      </div>

      {/* Main Tab Content */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {/* TAB 1: STRUCTURED FIELDS */}
        {activeTab === 'fields' && (
          <div className="space-y-3">
            {/* Header info */}
            <div className="flex items-center justify-between text-xs text-slate-400 pb-1 border-b border-slate-800/80">
              <span className="font-medium text-slate-300">
                Human-in-the-Loop Field Extraction & Audit
              </span>
              <span className="text-[11px] font-mono tabular-nums text-slate-400">
                Overall Confidence: {(document.confidenceScore * 100).toFixed(1)}%
              </span>
            </div>

            {/* Fields List */}
            <div className="space-y-2">
              {document.fields.map((field) => {
                const isSelected = selectedField?.key === field.key;
                const isEditing = editingKey === field.key;
                const confColor = getConfidenceColor(field.confidence);

                return (
                  <div
                    key={field.key}
                    onClick={() => onSelectField(field)}
                    className={`rounded-lg border transition-all p-3 text-xs ${
                      isSelected
                        ? 'border-cyan-500 bg-cyan-950/20 shadow-md shadow-cyan-950/20'
                        : 'border-slate-800/90 bg-slate-900/60 hover:border-slate-700'
                    }`}
                  >
                    {/* Header Row */}
                    <div className="flex items-center justify-between gap-2 mb-1.5">
                      <div className="flex items-center gap-2 min-w-0">
                        <span className="font-semibold text-slate-200 truncate">
                          {field.label}
                        </span>
                        {field.isCritical && (
                          <span className="text-[10px] font-mono font-medium px-1.5 py-0.2 rounded bg-amber-500/10 text-amber-300 border border-amber-500/30">
                            Critical
                          </span>
                        )}
                        {field.status === 'modified' && (
                          <span className="text-[10px] font-mono text-cyan-400 bg-cyan-500/10 px-1 rounded">
                            Human Modified
                          </span>
                        )}
                        {field.status === 'flagged' && (
                          <span className="text-[10px] font-mono text-rose-400 bg-rose-500/10 px-1 rounded">
                            Flagged
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        {/* Confidence score */}
                        <div
                          className={`flex items-center gap-1 font-mono text-[11px] px-1.5 py-0.5 rounded border tabular-nums ${confColor.bg} ${confColor.text} ${confColor.border}`}
                          title={`Confidence: ${(field.confidence * 100).toFixed(0)}%`}
                        >
                          <span>{(field.confidence * 100).toFixed(0)}%</span>
                        </div>

                        {/* Edit Button */}
                        {!isEditing && (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              startEdit(field);
                            }}
                            className="p-1 text-slate-400 hover:text-white rounded hover:bg-slate-800 transition-colors"
                            title="Edit field value"
                          >
                            <Edit2 className="w-3 h-3" />
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Field Value Display or Inline Edit Form */}
                    {isEditing ? (
                      <div className="mt-2 space-y-2" onClick={(e) => e.stopPropagation()}>
                        <textarea
                          rows={2}
                          value={editValue}
                          onChange={(e) => setEditValue(e.target.value)}
                          className="w-full bg-slate-950 border border-cyan-500 rounded px-2 py-1 text-xs text-slate-100 font-mono focus:outline-none focus:ring-1 focus:ring-cyan-400"
                        />
                        <div className="flex items-center justify-end gap-2">
                          <button
                            onClick={cancelEdit}
                            className="px-2 py-0.5 text-[11px] text-slate-400 hover:text-white rounded hover:bg-slate-800"
                          >
                            Cancel
                          </button>
                          <button
                            onClick={() => saveEdit(field.key)}
                            className="px-2.5 py-0.5 text-[11px] bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold rounded"
                          >
                            Save Override
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div className="font-mono text-slate-100 font-medium text-xs break-words bg-slate-950/60 p-2 rounded border border-slate-800/60">
                        {field.displayValue || String(field.value)}
                      </div>
                    )}

                    {/* Grounding Source Excerpt */}
                    {field.grounding && (
                      <div className="mt-2 pt-2 border-t border-slate-800/60 flex items-start gap-1.5 text-[11px] text-slate-400">
                        <span className="text-[10px] font-mono text-cyan-400/80 shrink-0 font-semibold">
                          [P.{field.grounding.pageNumber}]:
                        </span>
                        <span className="italic line-clamp-2 text-slate-300">
                          "{field.grounding.textExcerpt}"
                        </span>
                      </div>
                    )}

                    {/* Field Warning/Comment if exists */}
                    {field.comment && (
                      <div className="mt-2 flex items-center gap-1.5 text-[11px] text-amber-300/90 bg-amber-500/10 p-1.5 rounded border border-amber-500/20">
                        <AlertTriangle className="w-3 h-3 shrink-0" />
                        <span>{field.comment}</span>
                      </div>
                    )}

                    {/* Quick Audit Actions */}
                    <div className="mt-2.5 pt-1.5 border-t border-slate-800/60 flex items-center justify-between text-[11px]">
                      <div className="flex items-center gap-2">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onUpdateField(field.key, field.value, 'verified');
                          }}
                          className={`flex items-center gap-1 px-2 py-0.5 rounded transition-colors ${
                            field.status === 'verified'
                              ? 'text-emerald-400 bg-emerald-500/10 border border-emerald-500/30'
                              : 'text-slate-400 hover:text-emerald-300 hover:bg-slate-800'
                          }`}
                        >
                          <Check className="w-3 h-3" />
                          <span>{field.status === 'verified' ? 'Verified' : 'Verify'}</span>
                        </button>

                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onUpdateField(field.key, field.value, 'flagged');
                          }}
                          className={`flex items-center gap-1 px-2 py-0.5 rounded transition-colors ${
                            field.status === 'flagged'
                              ? 'text-rose-400 bg-rose-500/10 border border-rose-500/30'
                              : 'text-slate-400 hover:text-rose-300 hover:bg-slate-800'
                          }`}
                        >
                          <AlertCircle className="w-3 h-3" />
                          <span>Flag</span>
                        </button>
                      </div>

                      <span className="text-[10px] font-mono text-slate-500">
                        Key: {field.key}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* TAB 2: RISK RED FLAGS */}
        {activeTab === 'flags' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between text-xs text-slate-400 pb-1 border-b border-slate-800/80">
              <span className="font-medium text-slate-300">
                Automated Risk & Redline Assessment
              </span>
              <span className="text-[11px] font-mono tabular-nums text-rose-400">
                {document.redFlags.length} Risk Exposure(s)
              </span>
            </div>

            {document.redFlags.length === 0 ? (
              <div className="text-center py-10 bg-slate-900/40 rounded-lg border border-slate-800">
                <Check className="w-8 h-8 text-emerald-400 mx-auto mb-2 opacity-80" />
                <div className="text-sm font-medium text-slate-300">No Critical Red Flags Detected</div>
                <div className="text-xs text-slate-500 max-w-sm mx-auto mt-1">
                  Document complies with standard corporate governance and liability guidelines.
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                {document.redFlags.map((flag) => {
                  const badge = getSeverityBadge(flag.severity);
                  return (
                    <div
                      key={flag.id}
                      className="rounded-lg border border-slate-800 bg-slate-900/60 p-4 space-y-2.5 text-xs"
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="space-y-0.5">
                          <div className="flex items-center gap-2">
                            <span className={`text-[10px] font-mono font-semibold px-2 py-0.5 rounded border uppercase ${badge.bg} ${badge.text} ${badge.border}`}>
                              {badge.label}
                            </span>
                            <span className="text-[11px] text-slate-400">
                              {flag.category}
                            </span>
                          </div>
                          <h4 className="text-sm font-semibold text-slate-100 mt-1">
                            {flag.title}
                          </h4>
                        </div>
                      </div>

                      <p className="text-slate-300 text-xs leading-relaxed">
                        {flag.description}
                      </p>

                      {flag.clauseExcerpt && (
                        <div className="bg-slate-950 p-2.5 rounded border border-slate-800/80 font-mono text-[11px] text-slate-300 italic">
                          "{flag.clauseExcerpt}"
                        </div>
                      )}

                      {flag.recommendation && (
                        <div className="bg-cyan-950/30 border border-cyan-800/30 p-2.5 rounded flex items-start gap-2 text-cyan-200">
                          <Sparkles className="w-3.5 h-3.5 text-cyan-400 shrink-0 mt-0.5" />
                          <div className="text-[11px]">
                            <strong className="text-white">Recommendation: </strong>
                            {flag.recommendation}
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* TAB 3: VERTICAL-SPECIFIC DEEP VIEW */}
        {activeTab === 'vertical_view' && (
          <div className="space-y-4">
            {/* LEGAL VERTICAL VIEW */}
            {document.vertical === 'legal' && document.verticalData?.legal && (
              <div className="space-y-3">
                <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-4 space-y-3">
                  <div className="text-xs font-semibold text-slate-200 uppercase tracking-wider font-mono">
                    Contract Signatories & Legal Standing
                  </div>
                  <div className="grid grid-cols-2 gap-3 text-xs">
                    {document.verticalData.legal.parties.map((p, idx) => (
                      <div key={idx} className="bg-slate-950 p-2.5 rounded border border-slate-800">
                        <div className="text-slate-400 text-[10px] font-mono">{p.role}</div>
                        <div className="font-semibold text-slate-100 mt-0.5">{p.name}</div>
                        {p.jurisdiction && (
                          <div className="text-[10px] text-slate-500 font-mono mt-0.5">Jurisdiction: {p.jurisdiction}</div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-4 space-y-3">
                  <div className="text-xs font-semibold text-slate-200 uppercase tracking-wider font-mono">
                    Governance & Liability Exposure
                  </div>
                  <div className="space-y-2 text-xs">
                    <div className="flex justify-between py-1 border-b border-slate-800">
                      <span className="text-slate-400">Governing Law</span>
                      <span className="font-mono text-slate-200 font-semibold">{document.verticalData.legal.governingLaw}</span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-800">
                      <span className="text-slate-400">Jurisdiction Venue</span>
                      <span className="font-mono text-slate-200">{document.verticalData.legal.jurisdiction}</span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-800">
                      <span className="text-slate-400">Aggregate Liability Cap</span>
                      <span className="font-mono text-cyan-300 font-bold">{document.verticalData.legal.liabilityCapType}</span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-800">
                      <span className="text-slate-400">Auto-Renewal Notice</span>
                      <span className="font-mono text-slate-200">{document.verticalData.legal.renewalNoticeDays} Days Written Notice</span>
                    </div>
                    <div className="flex justify-between py-1">
                      <span className="text-slate-400">Confidentiality Protection</span>
                      <span className="font-mono text-slate-200">{document.verticalData.legal.confidentialityPeriodYears} Years (Trade Secrets Perpetual)</span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* INSURANCE VERTICAL VIEW */}
            {document.vertical === 'insurance' && document.verticalData?.insurance && (
              <div className="space-y-3">
                {/* SIU Fraud Score Bar */}
                <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-4 space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-300 font-semibold">Special Investigation Unit (SIU) Anomaly Score</span>
                    <span className="font-mono font-bold text-emerald-400">
                      {document.verticalData.insurance.fraudRiskScore} / 100 (Nominal)
                    </span>
                  </div>
                  <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-800">
                    <div
                      className="bg-emerald-400 h-full rounded-full transition-all"
                      style={{ width: `${document.verticalData.insurance.fraudRiskScore}%` }}
                    />
                  </div>
                  <div className="flex items-center gap-1.5 text-[11px] text-slate-400 pt-1">
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Telematics & Police Citation corroborated. Straight-Through Processing (STP) Eligible.</span>
                  </div>
                </div>

                {/* Line Items Table */}
                <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-4 space-y-3">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-slate-200 uppercase tracking-wider font-mono">
                      Itemized Damage & Repair Estimates
                    </span>
                    <span className="font-mono font-bold text-amber-400 tabular-nums">
                      {formatCurrency(document.verticalData.insurance.totalClaimAmount)}
                    </span>
                  </div>
                  <div className="border border-slate-800 rounded overflow-hidden">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-slate-950 text-slate-400 text-[10px] font-mono uppercase">
                        <tr>
                          <th className="p-2">Description</th>
                          <th className="p-2">Category</th>
                          <th className="p-2 text-right">Amount</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800">
                        {document.verticalData.insurance.lineItems.map((item, idx) => (
                          <tr key={idx} className="hover:bg-slate-900/50">
                            <td className="p-2 text-slate-200">{item.description}</td>
                            <td className="p-2 font-mono text-[11px] text-slate-400">{item.category}</td>
                            <td className="p-2 text-right font-mono text-slate-200 tabular-nums">
                              {formatCurrency(item.amount)}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {/* HEALTHCARE VERTICAL VIEW */}
            {document.vertical === 'healthcare' && document.verticalData?.healthcare && (
              <div className="space-y-3">
                {/* Clinical Coding Summary */}
                <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-4 space-y-3">
                  <div className="text-xs font-semibold text-slate-200 uppercase tracking-wider font-mono">
                    ICD-10 Clinical Diagnoses
                  </div>
                  <div className="space-y-1.5 text-xs">
                    <div className="bg-slate-950 p-2.5 rounded border border-slate-800 flex items-start justify-between gap-2">
                      <div>
                        <div className="font-mono text-emerald-400 font-bold">
                          {document.verticalData.healthcare.primaryDiagnosis.code}
                        </div>
                        <div className="text-slate-300 mt-0.5">
                          {document.verticalData.healthcare.primaryDiagnosis.description}
                        </div>
                      </div>
                      <span className="text-[10px] font-mono text-cyan-400 bg-cyan-500/10 px-1.5 py-0.5 rounded border border-cyan-500/30">
                        Primary Billable
                      </span>
                    </div>

                    {document.verticalData.healthcare.secondaryDiagnoses.map((sec, idx) => (
                      <div key={idx} className="bg-slate-950/60 p-2 rounded border border-slate-800/80 flex items-center justify-between text-xs">
                        <span className="font-mono text-slate-300 font-semibold">{sec.code}</span>
                        <span className="text-slate-400 text-[11px]">{sec.description}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Procedure & J-Codes */}
                <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-4 space-y-3">
                  <div className="text-xs font-semibold text-slate-200 uppercase tracking-wider font-mono">
                    HCPCS & CPT Procedures
                  </div>
                  <div className="space-y-1.5 text-xs">
                    {document.verticalData.healthcare.procedures.map((proc, idx) => (
                      <div key={idx} className="bg-slate-950 p-2 rounded border border-slate-800 flex items-center justify-between text-xs">
                        <div>
                          <span className="font-mono text-cyan-300 font-bold mr-2">{proc.code}</span>
                          <span className="text-slate-300">{proc.description}</span>
                        </div>
                        <span className="font-mono text-slate-400 text-[11px]">{proc.units} Unit(s)</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Medical Necessity */}
                <div className="bg-cyan-950/30 border border-cyan-800/40 rounded-lg p-3 text-xs space-y-1">
                  <div className="text-cyan-400 font-semibold font-mono text-[11px]">NCCN Category 1 Clinical Guideline Justification</div>
                  <div className="text-slate-200 text-xs">{document.verticalData.healthcare.medicalNecessitySummary}</div>
                </div>
              </div>
            )}

            {/* FINANCE VERTICAL VIEW */}
            {document.vertical === 'finance' && document.verticalData?.finance && (
              <div className="space-y-3">
                {/* 3-Way PO Match Status */}
                <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-4 space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-300 font-semibold">3-Way Purchase Order Reconciliation</span>
                    <span className="font-mono font-bold text-emerald-400">
                      Exact Match (0.00% Variance)
                    </span>
                  </div>
                  <div className="text-xs text-slate-400 flex items-center gap-2">
                    <span>PO Ref: <strong className="text-white font-mono">{document.verticalData.finance.purchaseOrderNumber}</strong></span>
                    <span>·</span>
                    <span>Vendor: <strong className="text-white">{document.verticalData.finance.vendorName}</strong></span>
                  </div>
                </div>

                {/* Line Items Table */}
                <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-4 space-y-3">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-slate-200 uppercase tracking-wider font-mono">
                      Invoice Charges & Line Items
                    </span>
                    <span className="font-mono font-bold text-cyan-300 tabular-nums">
                      {formatCurrency(document.verticalData.finance.totalAmount)}
                    </span>
                  </div>
                  <div className="border border-slate-800 rounded overflow-hidden">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-slate-950 text-slate-400 text-[10px] font-mono uppercase">
                        <tr>
                          <th className="p-2">Item Description</th>
                          <th className="p-2 text-right">Qty</th>
                          <th className="p-2 text-right">Unit Price</th>
                          <th className="p-2 text-right">Total</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800">
                        {document.verticalData.finance.lineItems.map((item, idx) => (
                          <tr key={idx} className="hover:bg-slate-900/50">
                            <td className="p-2 text-slate-200">{item.item}</td>
                            <td className="p-2 text-right font-mono text-slate-400 tabular-nums">{item.quantity}</td>
                            <td className="p-2 text-right font-mono text-slate-400 tabular-nums">{formatCurrency(item.unitPrice)}</td>
                            <td className="p-2 text-right font-mono text-slate-200 font-semibold tabular-nums">{formatCurrency(item.total)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* TAB 4: RAW JSON VIEW */}
        {activeTab === 'json' && (
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs text-slate-400 pb-1">
              <span>Standard Enterprise Extraction Schema Payload</span>
              <button
                onClick={handleCopyJson}
                className="text-cyan-400 hover:text-cyan-300 font-mono text-[11px]"
              >
                {copied ? 'Copied to Clipboard' : 'Copy All'}
              </button>
            </div>
            <pre className="bg-slate-950 p-4 rounded-lg border border-slate-800 text-[11px] font-mono text-cyan-200 overflow-x-auto leading-relaxed max-h-[500px]">
              {JSON.stringify(
                {
                  id: document.id,
                  title: document.title,
                  vertical: document.vertical,
                  documentType: document.documentType,
                  confidenceScore: document.confidenceScore,
                  fields: document.fields.reduce((acc, f) => ({ ...acc, [f.key]: f.value }), {}),
                  redFlags: document.redFlags,
                  verticalData: document.verticalData
                },
                null,
                2
              )}
            </pre>
          </div>
        )}
      </div>

      {/* Bottom Workflow Action Bar */}
      <div className="p-3 border-t border-slate-800/80 bg-slate-950 shrink-0 flex items-center justify-between gap-3">
        <div className="flex items-center gap-2 text-xs text-slate-400">
          <FileCheck className="w-4 h-4 text-emerald-400" />
          <span>Status: <strong className="text-white capitalize">{document.status.replace('_', ' ')}</strong></span>
        </div>

        <button
          disabled={isExecutingWorkflow}
          onClick={() => onRunWorkflow(
            document.vertical === 'legal'
              ? 'General Counsel High-Exposure Escalation'
              : document.vertical === 'insurance'
              ? 'Straight-Through Processing Auto-Adjudication'
              : document.vertical === 'healthcare'
              ? 'Expedited Prior-Authorization Fast-Track'
              : '3-Way PO Match & NetSuite AP Posting'
          )}
          className="flex items-center gap-2 px-3 py-1.5 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs rounded-lg transition-all shadow-md shadow-cyan-950/40 disabled:opacity-50"
        >
          {isExecutingWorkflow ? (
            <RefreshCw className="w-3.5 h-3.5 animate-spin" />
          ) : (
            <Play className="w-3.5 h-3.5 fill-current" />
          )}
          <span>{isExecutingWorkflow ? 'Executing Workflow...' : 'Execute Compliance Workflow'}</span>
        </button>
      </div>
    </div>
  );
};
