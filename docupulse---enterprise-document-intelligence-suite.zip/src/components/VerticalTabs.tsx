import React from 'react';
import { Scale, ShieldCheck, HeartPulse, Receipt, Sparkles } from 'lucide-react';
import { VerticalType } from '../types/document';
import { VERTICAL_CONFIGS } from '../data/verticalConfigs';

interface VerticalTabsProps {
  activeVertical: VerticalType;
  onSelect: (vertical: VerticalType) => void;
  documentCounts: Record<VerticalType, number>;
}

export const VerticalTabs: React.FC<VerticalTabsProps> = ({
  activeVertical,
  onSelect,
  documentCounts
}) => {
  const verticals: { id: VerticalType; icon: React.ReactNode; label: string; sub: string }[] = [
    {
      id: 'legal',
      icon: <Scale className="w-4 h-4" />,
      label: 'Legal Intelligence',
      sub: 'Contracts, MSAs & Redlines'
    },
    {
      id: 'insurance',
      icon: <ShieldCheck className="w-4 h-4" />,
      label: 'Insurance Claims',
      sub: 'FNOL, ACORD & Fraud Scoring'
    },
    {
      id: 'healthcare',
      icon: <HeartPulse className="w-4 h-4" />,
      label: 'Healthcare Prior-Auth',
      sub: 'Clinical ICD-10 & PHI Audit'
    },
    {
      id: 'finance',
      icon: <Receipt className="w-4 h-4" />,
      label: 'Finance & Invoices',
      sub: '3-Way PO Match & ERP Sync'
    }
  ];

  return (
    <div className="border-b border-slate-800/80 bg-slate-950/70 px-6 py-2 flex items-center justify-between gap-4 shrink-0 overflow-x-auto">
      <div className="flex items-center gap-1.5 min-w-max">
        {verticals.map((vert) => {
          const isActive = activeVertical === vert.id;
          const count = documentCounts[vert.id] || 0;
          return (
            <button
              key={vert.id}
              onClick={() => onSelect(vert.id)}
              className={`flex items-center gap-2.5 px-3.5 py-1.5 rounded-lg text-xs transition-all ${
                isActive
                  ? 'bg-slate-800 text-white border border-slate-700 font-medium shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900 border border-transparent'
              }`}
            >
              <span className={isActive ? 'text-cyan-400' : 'text-slate-500'}>
                {vert.icon}
              </span>
              <div className="text-left">
                <div className="leading-tight flex items-center gap-1.5">
                  <span>{vert.label}</span>
                  <span className="text-[10px] font-mono tabular-nums text-slate-500 bg-slate-900/80 px-1.5 py-0.5 rounded border border-slate-800">
                    {count}
                  </span>
                </div>
              </div>
            </button>
          );
        })}
      </div>

      <div className="hidden lg:flex items-center gap-2 text-xs text-slate-400">
        <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
        <span className="truncate max-w-md">
          {VERTICAL_CONFIGS[activeVertical].tagline}
        </span>
      </div>
    </div>
  );
};
