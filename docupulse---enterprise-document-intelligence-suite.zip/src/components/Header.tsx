import React from 'react';
import { FileText, Plus, Activity, Layers, Workflow, BarChart3, HelpCircle } from 'lucide-react';
import { VerticalType } from '../types/document';

interface HeaderProps {
  currentView: 'workspace' | 'queue' | 'workflows' | 'analytics';
  onViewChange: (view: 'workspace' | 'queue' | 'workflows' | 'analytics') => void;
  activeVertical: VerticalType;
  onVerticalChange: (vertical: VerticalType) => void;
  onOpenUpload: () => void;
  onOpenQA: () => void;
  documentCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  currentView,
  onViewChange,
  activeVertical,
  onVerticalChange,
  onOpenUpload,
  onOpenQA,
  documentCount
}) => {
  return (
    <header className="h-14 border-b border-slate-800 bg-slate-950/90 backdrop-blur-md px-6 flex items-center justify-between shrink-0 select-none z-30">
      {/* Zone 1: Single text element wordmark */}
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
            <FileText className="w-4 h-4" />
          </div>
          <span className="text-base font-semibold tracking-tight text-white">
            DocuPulse
          </span>
        </div>
        <span className="text-xs text-slate-500 font-mono tracking-wider hidden sm:inline">
          DOCUMENT INTELLIGENCE
        </span>
      </div>

      {/* Zone 2: Clean text navigation links */}
      <nav className="hidden md:flex items-center gap-1 bg-slate-900/60 p-1 rounded-lg border border-slate-800/80">
        <button
          onClick={() => onViewChange('workspace')}
          className={`flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
            currentView === 'workspace'
              ? 'bg-slate-800 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Layers className="w-3.5 h-3.5" />
          Inspector Workspace
        </button>

        <button
          onClick={() => onViewChange('queue')}
          className={`flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
            currentView === 'queue'
              ? 'bg-slate-800 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Activity className="w-3.5 h-3.5" />
          Batch Queue
          <span className="ml-1 text-[11px] font-mono tabular-nums text-slate-500">
            ({documentCount})
          </span>
        </button>

        <button
          onClick={() => onViewChange('workflows')}
          className={`flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
            currentView === 'workflows'
              ? 'bg-slate-800 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Workflow className="w-3.5 h-3.5" />
          Rules & Workflows
        </button>

        <button
          onClick={() => onViewChange('analytics')}
          className={`flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
            currentView === 'analytics'
              ? 'bg-slate-800 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <BarChart3 className="w-3.5 h-3.5" />
          Intelligence Metrics
        </button>
      </nav>

      {/* Zone 3: Primary Action & Tools */}
      <div className="flex items-center gap-3">
        <button
          onClick={onOpenQA}
          className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-slate-300 hover:text-white bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-lg transition-colors"
          title="Ask questions about the current document"
        >
          <HelpCircle className="w-3.5 h-3.5 text-cyan-400" />
          <span>Ask Doc AI</span>
        </button>

        <button
          onClick={onOpenUpload}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-lg transition-colors shadow-sm font-semibold tracking-wide"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Ingest Document</span>
        </button>
      </div>
    </header>
  );
};
