import React, { useState, useRef } from 'react';
import {
  UploadCloud,
  FileText,
  X,
  Sparkles,
  Scale,
  ShieldCheck,
  HeartPulse,
  Receipt,
  AlertCircle,
  CheckCircle2,
  FileCode
} from 'lucide-react';
import { DocumentItem, VerticalType } from '../types/document';
import { VERTICAL_CONFIGS } from '../data/verticalConfigs';

interface DocumentUploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onIngestComplete: (newDoc: DocumentItem) => void;
  defaultVertical: VerticalType;
}

export const DocumentUploadModal: React.FC<DocumentUploadModalProps> = ({
  isOpen,
  onClose,
  onIngestComplete,
  defaultVertical
}) => {
  const [vertical, setVertical] = useState<VerticalType>(defaultVertical);
  const [docType, setDocType] = useState<string>(VERTICAL_CONFIGS[defaultVertical].documentTypes[0]);
  const [documentTitle, setDocumentTitle] = useState<string>('');
  const [rawText, setRawText] = useState<string>('');
  const [file, setFile] = useState<File | null>(null);
  const [isExtracting, setIsExtracting] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const selectedFile = e.target.files[0];
      setFile(selectedFile);
      if (!documentTitle) {
        setDocumentTitle(selectedFile.name.replace(/\.[^/.]+$/, ''));
      }

      // Read text if text file
      if (selectedFile.type.includes('text') || selectedFile.name.endsWith('.txt')) {
        const reader = new FileReader();
        reader.onload = (event) => {
          setRawText((event.target?.result as string) || '');
        };
        reader.readAsText(selectedFile);
      }
    }
  };

  const handleLoadSample = (sampleType: VerticalType) => {
    setVertical(sampleType);
    if (sampleType === 'legal') {
      setDocumentTitle('Standard Mutual Non-Disclosure Agreement (TechCorp - Apex)');
      setDocType('Non-Disclosure Agreement (NDA)');
      setRawText(`MUTUAL NON-DISCLOSURE AGREEMENT

This Mutual Non-Disclosure Agreement ("Agreement") is made effective as of November 1, 2026, by and between TechCorp Solutions LLC ("TechCorp") and Apex Logistics Inc. ("Apex").

1. PURPOSE
The parties wish to explore a potential strategic distribution partnership concerning enterprise supply chain automation.

2. CONFIDENTIAL INFORMATION
"Confidential Information" means any proprietary technical, financial, or business data disclosed by one party to the other, whether orally or in writing.

3. EXCLUSIONS
Confidential Information does not include information that is publicly known or independently developed without reference to the disclosing party's data.

4. TERM AND OBLIGATIONS
The receiving party shall hold all Confidential Information in strict confidence for a period of three (3) years from the date of disclosure.

5. REMEDIES & GOVERNING LAW
This Agreement shall be governed by the laws of the State of Delaware. The parties acknowledge that unauthorized disclosure may cause irreparable harm entitling the disclosing party to seek injunctive relief without posting a bond.

6. LIMITATION OF LIABILITY
Neither party shall be liable for indirect, incidental, or consequential damages. Aggregate liability under this NDA shall not exceed $100,000 USD.`);
    } else if (sampleType === 'insurance') {
      setDocumentTitle('ACORD 25 Certificate of Liability & Property Claim');
      setDocType('ACORD 25 Property Damage Loss Notice');
      setRawText(`ACORD 25 - PROPERTY LOSS NOTICE & CLAIM FORM
CARRIER: Continental Mutual Underwriters
POLICY NUMBER: POL-PROP-2026-88192
INSURED: Precision Machining Works Inc.
LOCATION OF LOSS: 500 Industrial Blvd, Cleveland, OH 44101
DATE OF LOSS: September 18, 2026 at 03:30 AM EST
POLICE / FIRE REPORT: Cleveland Fire Dept Report #CFD-88912

DESCRIPTION OF DAMAGE:
Electrical fire origin in auxiliary compressor room damaged electrical junction box and 2 CNC milling centers. Water sprinkler activation damaged inventory.
TOTAL CLAIM ESTIMATE: $42,500.00 USD
DEDUCTIBLE: $5,000.00 USD
FRAUD SCORE: 8/100 (Clean history, fire department report confirms accidental wiring surge).`);
    } else if (sampleType === 'healthcare') {
      setDocumentTitle('Outpatient Chemotherapy Infusion Prior-Authorization');
      setDocType('Prior Authorization Clinical Necessity Request');
      setRawText(`CLINICAL PRIOR AUTHORIZATION REQUEST
PATIENT: Jonathan R. Hayes | DOB: 09/12/1974 (Age 52) | MRN: 8812-4012
SUBSCRIBER ID: AET-99410-02 | PLAN: Aetna Choice POS II
PROVIDER: Dr. Brenda Sterling, MD | NPI: 1482910481 | Facility: Mount Sinai Health

DIAGNOSIS CODES:
- Primary: ICD-10 C50.911 - Malignant neoplasm of unspecified site of right female breast
- Secondary: ICD-10 Z17.0 - Estrogen receptor positive status [ER+]

REQUESTED PROCEDURE / MEDICATION:
- HCPCS J9145: Daratumumab and hyaluronidase-fihj (1 unit)
- CPT 96409: Chemotherapy administration; intravenous, push technique, single or initial substance
URGENCY: Expedited Urgent (24hr)
MEDICAL NECESSITY: Patient has failed first-line hormonal therapy; meets NCCN Stage III metastatic pathway.`);
    } else {
      setDocumentTitle('Software Enterprise License & Cloud Invoice');
      setDocType('Commercial Vendor Tax Invoice');
      setRawText(`VERTEX ANALYTICS INC - INVOICE
Invoice #: INV-2026-4401
Invoice Date: September 20, 2026 | Due Date: October 20, 2026
Purchase Order: PO-899120-CORP
Customer: Meridian Cloud Systems, Inc.

ITEMS:
1. Enterprise Business Intelligence 50-Seat Subscription: $15,000.00
2. Dedicated Redshift Connector Engine: $3,500.00
3. Implementation Engineering Support (20 Hours @ $200): $4,000.00
SUBTOTAL: $22,500.00 USD
TAX (8.25%): $1,856.25 USD
TOTAL AMOUNT DUE: $24,356.25 USD
TERMS: Net 30 days.`);
    }
  };

  const handleStartExtraction = async () => {
    if (!rawText.trim() && !file) {
      setErrorMsg('Please enter document text or select a file to ingest.');
      return;
    }

    setIsExtracting(true);
    setErrorMsg(null);

    try {
      let base64Data: string | undefined;
      let mimeType = 'application/pdf';

      if (file) {
        mimeType = file.type || 'application/pdf';
        const buffer = await file.arrayBuffer();
        base64Data = btoa(
          new Uint8Array(buffer).reduce((data, byte) => data + String.fromCharCode(byte), '')
        );
      }

      const response = await fetch('/api/extract', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          documentText: rawText,
          documentBase64: base64Data,
          mimeType,
          vertical,
          documentType: docType
        })
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.details || errorData.error || 'Extraction failed');
      }

      const result = await response.json();
      const extracted = result.extracted;

      const newDocument: DocumentItem = {
        id: `doc-${vertical}-${Date.now()}`,
        title: documentTitle || extracted.documentTitle || `${vertical.toUpperCase()} Ingested Document`,
        filename: file?.name || `${(documentTitle || 'Document').replace(/\s+/g, '_')}.pdf`,
        fileSize: file ? `${(file.size / 1024).toFixed(0)} KB` : `${(rawText.length / 1024).toFixed(1)} KB`,
        fileType: file?.type || 'application/pdf',
        uploadedAt: new Date().toISOString(),
        vertical,
        documentType: docType || extracted.documentType || 'Contract',
        status: extracted.redFlags?.length > 0 ? 'in_review' : 'extracted',
        confidenceScore: extracted.confidenceScore || 0.94,
        pageCount: Math.max(1, Math.ceil(rawText.split('\n').length / 35)),
        rawText: rawText || (file ? `Document: ${file.name}\nExtracted via Gemini 3.8 Flash Optical Engine.` : ''),
        fields: extracted.fields || [],
        redFlags: extracted.redFlags || [],
        verticalData: {
          [vertical]: extracted.verticalData?.[vertical] || {}
        },
        workflows: [
          {
            id: `wf-${Date.now()}`,
            workflowName: `${vertical.toUpperCase()} Automated Compliance Triage`,
            status: 'completed',
            startedAt: new Date().toISOString(),
            completedAt: new Date().toISOString(),
            decision: extracted.redFlags?.length > 0 ? 'manual_review_required' : 'auto_approved',
            decisionRationale: extracted.redFlags?.length > 0
              ? `Flagged ${extracted.redFlags.length} risk issues requiring human reviewer sign-off.`
              : 'All standard extraction fields validated successfully.',
            steps: [
              {
                id: 's1',
                title: 'Gemini 3.8 Flash Optical & Semantic Ingestion',
                type: 'extraction',
                status: 'completed',
                message: `Extracted ${extracted.fields?.length || 0} structured fields.`
              },
              {
                id: 's2',
                title: 'Compliance Rule Matrix & Redline Analysis',
                type: 'validation',
                status: 'completed',
                message: `Evaluated ${extracted.redFlags?.length || 0} risk conditions.`
              }
            ]
          }
        ],
        auditTrail: [
          {
            timestamp: new Date().toISOString(),
            user: 'Gemini 3.8 Flash Engine',
            action: 'Document Ingestion & Schema Extraction',
            details: `Extracted ${extracted.fields?.length || 0} fields with confidence ${(extracted.confidenceScore * 100).toFixed(0)}%`
          }
        ]
      };

      onIngestComplete(newDocument);
      onClose();
    } catch (err: any) {
      console.error('Ingestion error:', err);
      setErrorMsg(err.message || 'Failed to extract document. Please check console.');
    } finally {
      setIsExtracting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-fadeIn">
      <div className="bg-slate-900 border border-slate-800 rounded-xl w-full max-w-3xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/80">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
              <UploadCloud className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-white">
                Ingest & Extract Enterprise Document
              </h3>
              <p className="text-xs text-slate-400">
                Upload PDFs, scanned contracts, claims or clinical forms for automated schema extraction
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-5">
          {errorMsg && (
            <div className="bg-rose-500/10 border border-rose-500/30 p-3 rounded-lg text-xs text-rose-300 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Quick Preset Selector */}
          <div className="space-y-2">
            <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider font-mono">
              Quick Industry Presets
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <button
                type="button"
                onClick={() => handleLoadSample('legal')}
                className={`flex items-center gap-2 p-2.5 rounded-lg border text-left text-xs transition-colors ${
                  vertical === 'legal'
                    ? 'border-indigo-500 bg-indigo-950/30 text-indigo-200'
                    : 'border-slate-800 bg-slate-950 hover:border-slate-700 text-slate-400'
                }`}
              >
                <Scale className="w-4 h-4 text-indigo-400 shrink-0" />
                <div>
                  <div className="font-semibold text-slate-200">Legal NDA</div>
                  <div className="text-[10px] text-slate-500">Contract & Risk</div>
                </div>
              </button>

              <button
                type="button"
                onClick={() => handleLoadSample('insurance')}
                className={`flex items-center gap-2 p-2.5 rounded-lg border text-left text-xs transition-colors ${
                  vertical === 'insurance'
                    ? 'border-amber-500 bg-amber-950/30 text-amber-200'
                    : 'border-slate-800 bg-slate-950 hover:border-slate-700 text-slate-400'
                }`}
              >
                <ShieldCheck className="w-4 h-4 text-amber-400 shrink-0" />
                <div>
                  <div className="font-semibold text-slate-200">ACORD 25</div>
                  <div className="text-[10px] text-slate-500">Property Claim</div>
                </div>
              </button>

              <button
                type="button"
                onClick={() => handleLoadSample('healthcare')}
                className={`flex items-center gap-2 p-2.5 rounded-lg border text-left text-xs transition-colors ${
                  vertical === 'healthcare'
                    ? 'border-emerald-500 bg-emerald-950/30 text-emerald-200'
                    : 'border-slate-800 bg-slate-950 hover:border-slate-700 text-slate-400'
                }`}
              >
                <HeartPulse className="w-4 h-4 text-emerald-400 shrink-0" />
                <div>
                  <div className="font-semibold text-slate-200">Prior-Auth</div>
                  <div className="text-[10px] text-slate-500">Clinical Oncology</div>
                </div>
              </button>

              <button
                type="button"
                onClick={() => handleLoadSample('finance')}
                className={`flex items-center gap-2 p-2.5 rounded-lg border text-left text-xs transition-colors ${
                  vertical === 'finance'
                    ? 'border-cyan-500 bg-cyan-950/30 text-cyan-200'
                    : 'border-slate-800 bg-slate-950 hover:border-slate-700 text-slate-400'
                }`}
              >
                <Receipt className="w-4 h-4 text-cyan-400 shrink-0" />
                <div>
                  <div className="font-semibold text-slate-200">Vendor Bill</div>
                  <div className="text-[10px] text-slate-500">Tax Invoice</div>
                </div>
              </button>
            </div>
          </div>

          {/* Form Fields */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="block text-slate-400 mb-1 font-medium">Document Title</label>
              <input
                type="text"
                placeholder="e.g. Master Services Agreement"
                value={documentTitle}
                onChange={(e) => setDocumentTitle(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-200 focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div>
              <label className="block text-slate-400 mb-1 font-medium">Classification Type</label>
              <select
                value={docType}
                onChange={(e) => setDocType(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-200 focus:outline-none focus:border-cyan-500"
              >
                {VERTICAL_CONFIGS[vertical].documentTypes.map((t) => (
                  <option key={t} value={t}>
                    {t}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* File Upload Zone */}
          <div className="space-y-2">
            <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider font-mono">
              Document File (PDF / Images / Text)
            </label>
            <div
              onClick={() => fileInputRef.current?.click()}
              className="border-2 border-dashed border-slate-800 hover:border-cyan-500/60 rounded-xl p-6 text-center cursor-pointer bg-slate-950/60 hover:bg-slate-950 transition-all group"
            >
              <input
                ref={fileInputRef}
                type="file"
                accept=".pdf,.txt,.json,.png,.jpg,.jpeg"
                onChange={handleFileChange}
                className="hidden"
              />
              <UploadCloud className="w-8 h-8 text-slate-500 group-hover:text-cyan-400 mx-auto mb-2 transition-colors" />
              <div className="text-xs font-medium text-slate-300">
                {file ? file.name : 'Click to browse or drop document file here'}
              </div>
              <div className="text-[11px] text-slate-500 mt-1">
                Supports PDF contracts, claims scans, clinical records, or plain text (up to 50MB)
              </div>
            </div>
          </div>

          {/* Raw Text Box */}
          <div className="space-y-1">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <label className="font-medium">Or Paste Document Raw Text / Clauses</label>
              <span className="text-[10px] font-mono text-slate-500">
                {rawText.length} characters
              </span>
            </div>
            <textarea
              rows={6}
              placeholder="Paste contract clauses, loss notice text, clinical notes, or invoice body here..."
              value={rawText}
              onChange={(e) => setRawText(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-xs text-slate-200 font-mono focus:outline-none focus:border-cyan-500"
            />
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-slate-800 bg-slate-950 flex items-center justify-between">
          <div className="text-xs text-slate-500 font-mono">
            Powered by Gemini 3.8 Flash Server-Side Optical OCR
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              disabled={isExtracting}
              className="px-4 py-2 text-xs text-slate-300 hover:text-white bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-lg transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={handleStartExtraction}
              disabled={isExtracting}
              className="flex items-center gap-2 px-5 py-2 text-xs font-bold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-lg transition-colors shadow-md shadow-cyan-950/40 disabled:opacity-50"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>{isExtracting ? 'Extracting with Gemini 3.8 Flash...' : 'Extract & Ingest'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
