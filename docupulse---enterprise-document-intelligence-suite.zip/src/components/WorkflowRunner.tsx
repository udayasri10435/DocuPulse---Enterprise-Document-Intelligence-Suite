import React, { useState } from 'react';
import {
  Workflow,
  CheckCircle2,
  Clock,
  AlertCircle,
  ExternalLink,
  Code,
  ArrowRight,
  ShieldCheck,
  Send,
  X,
  FileCheck,
  Check,
  RotateCcw
} from 'lucide-react';
import { DocumentItem, WorkflowExecution, WorkflowStep } from '../types/document';
import { VERTICAL_CONFIGS } from '../data/verticalConfigs';

interface WorkflowRunnerProps {
  document: DocumentItem;
  isOpen: boolean;
  onClose: () => void;
  onExecute: (workflowId: string, workflowName: string) => Promise<void>;
  isExecuting: boolean;
}

export const WorkflowRunner: React.FC<WorkflowRunnerProps> = ({
  document,
  isOpen,
  onClose,
  onExecute,
  isExecuting
}) => {
  const [selectedWorkflowIndex, setSelectedWorkflowIndex] = useState<number>(0);
  const [showPayload, setShowPayload] = useState<boolean>(false);

  if (!isOpen) return null;

  const verticalConfig = VERTICAL_CONFIGS[document.vertical];
  const activeExecution: WorkflowExecution | undefined = document.workflows[selectedWorkflowIndex] || document.workflows[0];

  const getDecisionBadge = (decision?: string) => {
    switch (decision) {
      case 'auto_approved':
      case 'billing_cleared':
        return { label: 'Automated STP Approval', color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30' };
      case 'escalated_to_counsel':
        return { label: 'Escalated to General Counsel', color: 'text-orange-400 bg-orange-500/10 border-orange-500/30' };
      case 'siu_flagged':
        return { label: 'SIU Fraud Review Hold', color: 'text-rose-400 bg-rose-500/10 border-rose-500/30' };
      default:
        return { label: 'Manual Review Required', color: 'text-amber-400 bg-amber-500/10 border-amber-500/30' };
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-fadeIn">
      <div className="bg-slate-900 border border-slate-800 rounded-xl w-full max-w-4xl max-h-[85vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/80">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
              <Workflow className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-white">
                Compliance Workflow Engine
              </h3>
              <p className="text-xs text-slate-400">
                Automated triage, policy rules & downstream ERP/CLM dispatch for <strong className="text-slate-200">{document.title}</strong>
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Vertical Standard Rules available */}
          <div className="space-y-2">
            <div className="text-xs font-semibold text-slate-300 uppercase tracking-wider font-mono">
              Available Workflows for {verticalConfig.name}
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {verticalConfig.standardWorkflows.map((wf) => (
                <div
                  key={wf.id}
                  className="bg-slate-950/70 border border-slate-800 p-3 rounded-lg space-y-2 text-xs hover:border-slate-700 transition-colors"
                >
                  <div className="font-semibold text-slate-100 flex items-center justify-between">
                    <span>{wf.name}</span>
                  </div>
                  <p className="text-slate-400 text-[11px] leading-relaxed">
                    {wf.description}
                  </p>
                  <div className="pt-1 border-t border-slate-800/80 flex items-center justify-between">
                    <span className="text-[10px] font-mono text-cyan-400/90 truncate max-w-[170px]" title={wf.trigger}>
                      Trigger: {wf.trigger}
                    </span>
                    <button
                      disabled={isExecuting}
                      onClick={() => onExecute(wf.id, wf.name)}
                      className="px-2 py-0.5 text-[11px] bg-slate-800 hover:bg-cyan-500 hover:text-slate-950 font-medium text-slate-200 rounded transition-colors disabled:opacity-50"
                    >
                      Run
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Current Execution Pipeline Trace */}
          {activeExecution && (
            <div className="bg-slate-950 border border-slate-800 rounded-lg p-5 space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-semibold text-white">
                      {activeExecution.workflowName}
                    </span>
                    <span className="text-[10px] font-mono text-slate-500">
                      ID: {activeExecution.id}
                    </span>
                  </div>
                  {activeExecution.decision && (
                    <div className="flex items-center gap-2">
                      <span className={`text-[10px] font-mono font-semibold px-2 py-0.5 rounded border ${getDecisionBadge(activeExecution.decision).color}`}>
                        {getDecisionBadge(activeExecution.decision).label}
                      </span>
                    </div>
                  )}
                </div>

                <div className="text-right">
                  <span className="text-[11px] font-mono text-slate-400">
                    Execution Time: ~1.2s
                  </span>
                </div>
              </div>

              {/* Rationale Notice */}
              {activeExecution.decisionRationale && (
                <div className="bg-slate-900 p-3 rounded border border-slate-800 text-xs text-slate-300 flex items-start gap-2">
                  <ShieldCheck className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-white">Audit Decision Rationale: </strong>
                    {activeExecution.decisionRationale}
                  </div>
                </div>
              )}

              {/* Steps Timeline */}
              <div className="space-y-3 pt-2">
                <div className="text-xs font-mono text-slate-400 uppercase tracking-wider">
                  Live Execution Steps
                </div>
                <div className="space-y-2">
                  {activeExecution.steps.map((step, idx) => (
                    <div
                      key={step.id || idx}
                      className="bg-slate-900/60 border border-slate-800/80 p-3 rounded flex items-start justify-between gap-3 text-xs"
                    >
                      <div className="flex items-start gap-2.5">
                        <div className="w-5 h-5 rounded-full bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shrink-0 mt-0.5">
                          <Check className="w-3 h-3" />
                        </div>
                        <div>
                          <div className="font-semibold text-slate-200">
                            {idx + 1}. {step.title}
                          </div>
                          {step.message && (
                            <div className="text-slate-400 text-[11px] mt-0.5">
                              {step.message}
                            </div>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        {step.outputPayload && (
                          <button
                            onClick={() => setShowPayload(!showPayload)}
                            className="text-[10px] font-mono text-cyan-400 hover:underline flex items-center gap-1"
                          >
                            <Code className="w-3 h-3" />
                            <span>Payload</span>
                          </button>
                        )}
                        <span className="font-mono text-[10px] text-slate-500">
                          {step.timestamp || 'Completed'}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Payload Viewer Accordion */}
              {showPayload && activeExecution.steps.find((s) => s.outputPayload) && (
                <div className="bg-black/60 border border-slate-800 p-3 rounded text-[11px] font-mono space-y-1">
                  <div className="text-cyan-400 font-semibold">Dispatched Webhook Payload Preview:</div>
                  <pre className="text-slate-300 overflow-x-auto max-h-48">
                    {JSON.stringify(
                      activeExecution.steps.find((s) => s.outputPayload)?.outputPayload,
                      null,
                      2
                    )}
                  </pre>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3 border-t border-slate-800 bg-slate-950 flex items-center justify-between">
          <div className="text-xs text-slate-500 font-mono">
            Complies with SOC2 Type II, HIPAA BAA & GDPR Data Standards
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-1.5 text-xs text-slate-300 hover:text-white bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-lg transition-colors"
            >
              Close
            </button>
            <button
              disabled={isExecuting}
              onClick={() => onExecute('wf-rerun', activeExecution?.workflowName || 'Compliance Workflow')}
              className="flex items-center gap-1.5 px-4 py-1.5 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-lg transition-colors shadow-sm disabled:opacity-50"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>{isExecuting ? 'Running...' : 'Re-Run Pipeline'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
