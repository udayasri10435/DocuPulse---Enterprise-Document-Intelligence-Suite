export type VerticalType = 'legal' | 'insurance' | 'healthcare' | 'finance';

export type DocumentStatus = 
  | 'uploaded'
  | 'extracting'
  | 'extracted'
  | 'in_review'
  | 'workflow_active'
  | 'approved'
  | 'flagged'
  | 'rejected';

export type FieldStatus = 'verified' | 'modified' | 'flagged' | 'low_confidence';

export interface GroundingReference {
  pageNumber: number;
  textExcerpt: string;
  charStart?: number;
  charEnd?: number;
  confidence: number;
}

export interface ExtractedField {
  key: string;
  label: string;
  value: any;
  displayValue?: string;
  type: 'string' | 'number' | 'currency' | 'date' | 'boolean' | 'array' | 'object' | 'badge';
  confidence: number; // 0.0 - 1.0
  status: FieldStatus;
  grounding?: GroundingReference;
  comment?: string;
  isCritical?: boolean;
}

export interface RedFlagAlert {
  id: string;
  category: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  title: string;
  description: string;
  clauseExcerpt?: string;
  recommendation?: string;
  resolved?: boolean;
}

export interface WorkflowStep {
  id: string;
  title: string;
  type: 'extraction' | 'validation' | 'rule_evaluation' | 'human_review' | 'dispatch_webhook' | 'erp_export';
  status: 'pending' | 'running' | 'completed' | 'failed' | 'skipped';
  message?: string;
  timestamp?: string;
  outputPayload?: any;
}

export interface WorkflowExecution {
  id: string;
  workflowName: string;
  status: 'pending' | 'running' | 'completed' | 'escalated' | 'failed';
  startedAt: string;
  completedAt?: string;
  steps: WorkflowStep[];
  decision?: 'auto_approved' | 'escalated_to_counsel' | 'siu_flagged' | 'billing_cleared' | 'manual_review_required';
  decisionRationale?: string;
}

export interface DocumentItem {
  id: string;
  title: string;
  filename: string;
  fileSize: string;
  fileType: string;
  uploadedAt: string;
  vertical: VerticalType;
  documentType: string; // e.g. "Master Services Agreement", "Commercial Property Loss Notice", "Prior Authorization Form"
  status: DocumentStatus;
  confidenceScore: number; // overall average
  pageCount: number;
  rawText: string;
  base64Data?: string; // For PDFs/images if available
  mimeType?: string;
  
  // Structured extractions
  fields: ExtractedField[];
  redFlags: RedFlagAlert[];
  
  // Vertical-specific structured payloads
  verticalData?: {
    legal?: LegalPayload;
    insurance?: InsurancePayload;
    healthcare?: HealthcarePayload;
    finance?: FinancePayload;
  };
  
  // Workflows attached
  workflows: WorkflowExecution[];
  auditTrail: {
    timestamp: string;
    user: string;
    action: string;
    details?: string;
  }[];
}

// Vertical-specific typed payloads
export interface LegalPayload {
  contractTitle: string;
  parties: { name: string; role: string; jurisdiction?: string }[];
  effectiveDate: string;
  terminationDate: string;
  governingLaw: string;
  jurisdiction: string;
  liabilityCapAmount: number | null;
  liabilityCapType: string; // e.g. "12 Months Fees", "Fixed $1,000,000", "Uncapped"
  indemnificationScope: string;
  confidentialityPeriodYears: number | null;
  nonCompeteIncluded: boolean;
  nonCompeteDurationMonths: number | null;
  autoRenewal: boolean;
  renewalNoticeDays: number | null;
  riskRating: 'Low' | 'Moderate' | 'High' | 'Severe';
}

export interface InsurancePayload {
  policyNumber: string;
  insuredName: string;
  insuranceCarrier: string;
  coverageType: string;
  policyLimit: number;
  deductible: number;
  incidentDate: string;
  incidentLocation: string;
  claimantName: string;
  lossDescription: string;
  totalClaimAmount: number;
  lineItems: { description: string; category: string; amount: number; covered: boolean }[];
  fraudRiskScore: number; // 0 - 100
  fraudIndicators: string[];
  subrogationPotential: boolean;
  straightThroughProcessingEligible: boolean;
}

export interface HealthcarePayload {
  patientName: string;
  patientDOB: string;
  patientMRN: string;
  subscriberID: string;
  orderingProvider: string;
  providerNPI: string;
  facilityName: string;
  encounterDate: string;
  primaryDiagnosis: { code: string; description: string; billable: boolean };
  secondaryDiagnoses: { code: string; description: string }[];
  procedures: { code: string; description: string; units: number; standardPrice?: number }[];
  medications: { drugName: string; dosage: string; frequency: string; route: string }[];
  medicalNecessitySummary: string;
  priorAuthUrgency: 'Standard (72hr)' | 'Expedited Urgent (24hr)' | 'Retrospective';
  priorAuthApproved: boolean | null;
  phiEntitiesRedactedCount: number;
}

export interface FinancePayload {
  invoiceNumber: string;
  vendorName: string;
  vendorTaxId: string;
  vendorAddress: string;
  customerName: string;
  purchaseOrderNumber: string;
  invoiceDate: string;
  dueDate: string;
  paymentTerms: string;
  currency: string;
  lineItems: { item: string; sku?: string; quantity: number; unitPrice: number; total: number }[];
  subtotal: number;
  taxRatePercent: number;
  taxAmount: number;
  totalAmount: number;
  poMatchStatus: 'Exact Match' | 'Variance Detected' | 'No PO Found';
  poVarianceAmount: number;
  bankDetails: { bankName?: string; routingNumber?: string; accountLast4?: string; iban?: string };
}
