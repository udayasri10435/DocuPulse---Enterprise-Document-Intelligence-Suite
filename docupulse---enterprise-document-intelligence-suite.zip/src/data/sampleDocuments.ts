import { DocumentItem } from '../types/document';

export const SAMPLE_DOCUMENTS: DocumentItem[] = [
  // 1. LEGAL VERTICAL
  {
    id: 'doc-legal-001',
    title: 'Master Cloud Services & License Agreement (Apex - Meridian)',
    filename: 'Apex_Meridian_MSA_Executed.pdf',
    fileSize: '412 KB',
    fileType: 'application/pdf',
    uploadedAt: '2026-09-28T14:30:00Z',
    vertical: 'legal',
    documentType: 'Master Services Agreement (MSA)',
    status: 'in_review',
    confidenceScore: 0.94,
    pageCount: 4,
    rawText: `MASTER SERVICES AND SOFTWARE LICENSE AGREEMENT

This Master Services and Software License Agreement ("Agreement") is entered into and made effective as of October 1, 2026 ("Effective Date"), by and between:

PROVIDER: Meridian Cloud Systems, Inc., a Delaware corporation with principal offices at 450 Mission Street, Suite 1800, San Francisco, California 94105 ("Meridian"), and
CUSTOMER: Apex Global Logistics LLC, a Texas limited liability company with principal offices at 1200 Industrial Parkway, Suite 400, Houston, Texas 77002 ("Apex").

RECITALS
WHEREAS, Meridian provides cloud-hosted enterprise logistics management software and related implementation engineering services; and
WHEREAS, Apex desires to license said software and engage Meridian for recurring platform subscription and specialized integration services.

1. SCOPE OF SERVICES AND LICENSE GRANT
Subject to the terms and conditions herein, Meridian hereby grants to Apex a non-exclusive, non-transferable, revocable subscription license to access the Meridian FreightHub Platform during the Subscription Term.

2. TERM AND AUTO-RENEWAL
2.1 Initial Term. This Agreement shall commence on the Effective Date and remain in full force for an initial period of thirty-six (36) months ("Initial Term"), terminating on September 30, 2029, unless terminated earlier in accordance with Section 8.
2.2 Automatic Renewal. Upon expiration of the Initial Term, this Agreement shall automatically renew for successive twelve (12) month terms, unless either party provides written notice of non-renewal at least sixty (60) days prior to the expiration of the then-current term.

3. FEES AND PAYMENT SCHEDULE
Apex shall pay Meridian annual recurring subscription fees of $240,000 USD billed in equal quarterly installments of $60,000 USD net thirty (30) days from the date of invoice. Late payments shall incur a monthly finance charge of 1.5%.

4. CONFIDENTIALITY
4.1 Definition. "Confidential Information" means all non-public proprietary information disclosed by either party.
4.2 Protection Period. The receiving party shall safeguard all Confidential Information with the same degree of care it uses for its own confidential assets (not less than reasonable care) for a duration of five (5) years following the termination or expiration of this Agreement; provided, however, that Trade Secrets shall remain confidential in perpetuity.

5. INTELLECTUAL PROPERTY RIGHTS
Meridian retains sole and exclusive ownership of all right, title, and interest in and to the FreightHub software, documentation, enhancements, algorithms, and underlying AI models. Apex retains sole ownership of all customer shipment data uploaded to the platform.

6. LIMITATION OF LIABILITY
6.1 Aggregate Cap. EXCEPT FOR GROSS NEGLIGENCE, WILLFUL MISCONDUCT, OR BREACH OF SECTION 4 (CONFIDENTIALITY), NEITHER PARTY'S AGGREGATE LIABILITY ARISING OUT OF OR RELATED TO THIS AGREEMENT SHALL EXCEED THE TOTAL FEES PAID OR PAYABLE BY CUSTOMER UNDER THIS AGREEMENT IN THE TWELVE (12) MONTHS PRECEDING THE INCIDENT GIVING RISE TO LIABILITY, OR FIVE HUNDRED THOUSAND DOLLARS ($500,000 USD), WHICHEVER IS GREATER.
6.2 Consequential Damages Waiver. IN NO EVENT SHALL EITHER PARTY BE LIABLE FOR ANY INDIRECT, PUNITIVE, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES (INCLUDING LOSS OF PROFITS, REVENUE, OR DATA).

7. INDEMNIFICATION
7.1 Meridian IP Indemnity. Meridian shall defend, indemnify, and hold harmless Apex, its officers, and employees against any third-party claims alleging that the FreightHub Platform infringes any valid United States patent, copyright, or trademark.
7.2 Unlimited Liability Carve-out. The liability limitations set forth in Section 6.1 shall expressly NOT apply to indemnification obligations under this Section 7 or damages resulting from breaches of data protection and privacy representations.

8. GOVERNING LAW AND JURISDICTION
This Agreement shall be governed by and construed in accordance with the substantive laws of the State of Delaware, without giving effect to conflict of laws principles. The parties irrevocably consent to the exclusive personal jurisdiction of the state and federal courts located in New Castle County, Delaware.

IN WITNESS WHEREOF, the authorized representatives have executed this Agreement as of the Effective Date.
MERIDIAN CLOUD SYSTEMS, INC.: By: /s/ Marcus Chen, VP Corporate Development
APEX GLOBAL LOGISTICS LLC: By: /s/ Sarah Jenkins, Chief Legal Counsel`,
    fields: [
      {
        key: 'contractTitle',
        label: 'Contract Title',
        value: 'Master Services and Software License Agreement',
        type: 'string',
        confidence: 0.98,
        status: 'verified',
        grounding: { pageNumber: 1, textExcerpt: 'MASTER SERVICES AND SOFTWARE LICENSE AGREEMENT', confidence: 0.99 }
      },
      {
        key: 'partyProvider',
        label: 'Provider (Licensor)',
        value: 'Meridian Cloud Systems, Inc. (Delaware)',
        type: 'string',
        confidence: 0.97,
        status: 'verified',
        grounding: { pageNumber: 1, textExcerpt: 'Meridian Cloud Systems, Inc., a Delaware corporation', confidence: 0.98 }
      },
      {
        key: 'partyCustomer',
        label: 'Customer (Licensee)',
        value: 'Apex Global Logistics LLC (Texas)',
        type: 'string',
        confidence: 0.97,
        status: 'verified',
        grounding: { pageNumber: 1, textExcerpt: 'Apex Global Logistics LLC, a Texas limited liability company', confidence: 0.97 }
      },
      {
        key: 'effectiveDate',
        label: 'Effective Date',
        value: '2026-10-01',
        displayValue: 'October 1, 2026',
        type: 'date',
        confidence: 0.99,
        status: 'verified',
        grounding: { pageNumber: 1, textExcerpt: 'effective as of October 1, 2026 ("Effective Date")', confidence: 0.99 }
      },
      {
        key: 'terminationDate',
        label: 'Initial Expiration Date',
        value: '2029-09-30',
        displayValue: 'September 30, 2029 (36 Months)',
        type: 'date',
        confidence: 0.95,
        status: 'verified',
        grounding: { pageNumber: 1, textExcerpt: 'terminating on September 30, 2029', confidence: 0.96 }
      },
      {
        key: 'liabilityCap',
        label: 'Liability Cap Amount',
        value: '$500,000 USD (or 12 Mo Fees)',
        type: 'currency',
        confidence: 0.96,
        status: 'verified',
        isCritical: true,
        grounding: { pageNumber: 2, textExcerpt: 'OR FIVE HUNDRED THOUSAND DOLLARS ($500,000 USD), WHICHEVER IS GREATER', confidence: 0.96 }
      },
      {
        key: 'indemnificationCarveOut',
        label: 'Uncapped Liability Carve-outs',
        value: 'IP Indemnity & Data Privacy breaches are uncapped',
        type: 'string',
        confidence: 0.91,
        status: 'flagged',
        isCritical: true,
        grounding: { pageNumber: 2, textExcerpt: 'limitations set forth in Section 6.1 shall expressly NOT apply to indemnification obligations', confidence: 0.93 },
        comment: 'High Exposure: IP indemnity and data protection breaches have no dollar ceiling.'
      },
      {
        key: 'governingLaw',
        label: 'Governing Law & Venue',
        value: 'State of Delaware (New Castle County)',
        type: 'string',
        confidence: 0.98,
        status: 'verified',
        grounding: { pageNumber: 3, textExcerpt: 'State of Delaware ... New Castle County, Delaware', confidence: 0.98 }
      },
      {
        key: 'autoRenewalNotice',
        label: 'Auto-Renewal Notice Window',
        value: '60 days prior to term expiration',
        type: 'string',
        confidence: 0.94,
        status: 'verified',
        grounding: { pageNumber: 1, textExcerpt: 'notice of non-renewal at least sixty (60) days prior', confidence: 0.95 }
      }
    ],
    redFlags: [
      {
        id: 'rf-1',
        category: 'Indemnification & Exposure',
        severity: 'high',
        title: 'Uncapped IP & Data Breach Liability',
        description: 'Section 7.2 creates an uncapped carve-out from Section 6 liability caps for IP indemnity and data privacy violations.',
        clauseExcerpt: 'limitations set forth in Section 6.1 shall expressly NOT apply to indemnification obligations under this Section 7 or damages resulting from breaches of data protection',
        recommendation: 'Request super-cap of $2,000,000 or 3x annual contract value on data privacy obligations.'
      },
      {
        id: 'rf-2',
        category: 'Term & Renewal',
        severity: 'medium',
        title: 'Automated 12-Month Evergreen Renewal',
        description: 'Auto-renews for 12 months unless cancelled 60 days in advance.',
        clauseExcerpt: 'automatically renew for successive twelve (12) month terms, unless either party provides written notice of non-renewal at least sixty (60) days prior',
        recommendation: 'Add renewal milestone reminder to contract lifecycle manager 90 days prior.'
      }
    ],
    verticalData: {
      legal: {
        contractTitle: 'Master Services and Software License Agreement',
        parties: [
          { name: 'Meridian Cloud Systems, Inc.', role: 'Provider', jurisdiction: 'Delaware' },
          { name: 'Apex Global Logistics LLC', role: 'Customer', jurisdiction: 'Texas' }
        ],
        effectiveDate: '2026-10-01',
        terminationDate: '2029-09-30',
        governingLaw: 'Delaware',
        jurisdiction: 'New Castle County, Delaware',
        liabilityCapAmount: 500000,
        liabilityCapType: 'Greater of 12 Months Fees or $500,000',
        indemnificationScope: 'Third-party patent/copyright/trademark infringement with uncapped ceiling',
        confidentialityPeriodYears: 5,
        nonCompeteIncluded: false,
        nonCompeteDurationMonths: null,
        autoRenewal: true,
        renewalNoticeDays: 60,
        riskRating: 'Moderate'
      }
    },
    workflows: [
      {
        id: 'wf-legal-01',
        workflowName: 'High-Value Contract Risk Review',
        status: 'escalated',
        startedAt: '2026-09-28T14:31:00Z',
        completedAt: '2026-09-28T14:31:04Z',
        decision: 'escalated_to_counsel',
        decisionRationale: 'Escalated to General Counsel: Section 7.2 introduces uncapped third-party indemnity carve-out exceeding $500k standard threshold.',
        steps: [
          { id: 's1', title: 'Gemini Document Ingestion & Optical OCR', type: 'extraction', status: 'completed', timestamp: '14:31:01', message: 'Extracted 14 critical legal clauses across 4 pages.' },
          { id: 's2', title: 'Contract Governance Compliance Check', type: 'validation', status: 'completed', timestamp: '14:31:02', message: 'Delaware Law accepted. Term dates validated.' },
          { id: 's3', title: 'Liability Threshold Policy Rule', type: 'rule_evaluation', status: 'completed', timestamp: '14:31:03', message: 'Rule triggered: [Liability Cap Carve-out == Uncapped] -> Requires Senior Counsel review.' },
          { id: 's4', title: 'Ironclad CLM & DocuSign Hold', type: 'dispatch_webhook', status: 'completed', timestamp: '14:31:04', message: 'Contract status set to PENDING_LEGAL_ESCALATION in Ironclad CLM.', outputPayload: { ironcladRecordId: 'REC-99482', reviewer: 'General Counsel Group', priority: 'HIGH' } }
        ]
      }
    ],
    auditTrail: [
      { timestamp: '2026-09-28 14:30:02', user: 'AI Ingestion Engine', action: 'Document Uploaded', details: 'Parsed 4 pages with PDF rasterizer' },
      { timestamp: '2026-09-28 14:31:00', user: 'Gemini 3.8 Flash', action: 'Structured Schema Extracted', details: 'Extracted 9 schema fields with avg confidence 94%' },
      { timestamp: '2026-09-28 14:31:04', user: 'Workflow Engine', action: 'Escalation Dispatched', details: 'Triggered Legal Counsel Escalation workflow' }
    ]
  },

  // 2. INSURANCE VERTICAL
  {
    id: 'doc-ins-002',
    title: 'Commercial Auto & Cargo Loss Notice (Swiftline Freight)',
    filename: 'ACORD_80_LossNotice_TX_9812.pdf',
    fileSize: '620 KB',
    fileType: 'application/pdf',
    uploadedAt: '2026-09-28T16:15:00Z',
    vertical: 'insurance',
    documentType: 'ACORD 80 First Notice of Loss (FNOL)',
    status: 'extracted',
    confidenceScore: 0.96,
    pageCount: 2,
    rawText: `ACORD 80 - AUTOMOBILE LOSS NOTICE (COMMERCIAL FLEET)

AGENCY / BROKER: Gulf Coast Risk Partners, Houston TX (Agency Code: GC-8812)
CARRIER: Vanguard Mutual Commercial Casualty Insurance Co.
POLICY NUMBER: POL-COMM-892104-TX
POLICY PERIOD: 01/01/2026 to 01/01/2027
COMMERCIAL AUTO LIMIT: $1,000,000 Combined Single Limit (CSL)
COLLISION DEDUCTIBLE: $2,500.00 | CARGO COVERAGE LIMIT: $250,000.00

INSURED DETAILS
Named Insured: Swiftline Intermodal Hauling Corp.
Address: 4800 Navigation Blvd, Building C, Houston, TX 77011
Contact Person: David Ramirez, Fleet Safety Director (Phone: 713-555-0194)

LOSS OCCURRENCE & LOCATION
Date of Incident: September 22, 2026 at approximately 14:45 CST
Location of Accident: Interstate 10 Eastbound, Mile Marker 782, Baytown, TX
Police Department: Baytown Police Department | Police Report Number: TX-BPD-2026-09941
Officer Name: Officer K. Morales, Badge #412
Citation Issued: No citations issued to Swiftline driver. Third party cited for Failure to Control Speed.

VEHICLE & DRIVER INFORMATION
Insured Vehicle: 2024 Freightliner Cascadia 126 Sleeper Cab | VIN: 1FUJGLDR8RL982140
Trailer Number: T-841 (Refrigerated 53ft Utility Trailer)
Swiftline Driver: Marcus Vance, CDL Class A #TX-8849102, Valid medical certificate on file.
Third-Party Vehicle: 2021 Ford F-250 Super Duty | Driver: Raymond Castillo, Insured by State Farm (Policy #SF-991204)

DESCRIPTION OF LOSS AND DAMAGED PROPERTY
Swiftline tractor-trailer was travelling eastbound in right-center lane at 55 MPH in heavy rain when third-party vehicle attempted rapid lane change from access ramp, hydroplaned, and struck the right front steer tire and side fuel tank skirt. Swiftline driver executed controlled deceleration without jackknifing.
Damage to Tractor: Right front steer axle displacement, bumper assembly destroyed, auxiliary fuel tank puncture, steer tire rim bent.
Damage to Cargo: Internal refrigeration unit lost auxiliary power for 2 hours; temperature rose from 34°F to 52°F, spoiling 4 pallets of organic pharmaceutical reagents.

ITEMIZED DAMAGE ESTIMATE
1. Freightliner Steer Axle & Suspension Repair: $8,450.00
2. Replacement Front Bumper & Sensor Assembly: $3,200.00
3. Commercial Towing & Heavy Recovery (Baytown Towing): $1,850.00
4. Auxiliary Fuel Tank & Deflector Replacement: $2,450.00
5. Spoiled Cargo Value (Refrigerated Pharma Lot #PH-2026-09): $8,900.00
TOTAL ESTIMATED LOSS: $24,850.00 USD

SUBROGATION / LIABILITY ASSESSMENT
Third-party driver cited for unsafe lane change under Texas Transportation Code 545.060. State Farm claim has been initiated by broker. Vanguard subrogation potential is deemed 100% recoverable.

FRAUD DETECTION & ANOMALY SIGNALS
Telematics Event Data Recorder (EDR) data confirms truck speed was 54.8 MPH in a 65 MPH zone. Front-facing dashcam video corroborates driver narrative. No prior claim history on this driver in 48 months. Fraud score is extremely low (4/100).`,
    fields: [
      {
        key: 'policyNumber',
        label: 'Policy Number',
        value: 'POL-COMM-892104-TX',
        type: 'string',
        confidence: 0.99,
        status: 'verified',
        grounding: { pageNumber: 1, textExcerpt: 'POLICY NUMBER: POL-COMM-892104-TX', confidence: 0.99 }
      },
      {
        key: 'insuredName',
        label: 'Named Insured',
        value: 'Swiftline Intermodal Hauling Corp.',
        type: 'string',
        confidence: 0.98,
        status: 'verified',
        grounding: { pageNumber: 1, textExcerpt: 'Named Insured: Swiftline Intermodal Hauling Corp.', confidence: 0.98 }
      },
      {
        key: 'incidentDate',
        label: 'Date & Time of Loss',
        value: '2026-09-22 14:45 CST',
        type: 'date',
        confidence: 0.98,
        status: 'verified',
        grounding: { pageNumber: 1, textExcerpt: 'Date of Incident: September 22, 2026 at approximately 14:45 CST', confidence: 0.99 }
      },
      {
        key: 'incidentLocation',
        label: 'Loss Location',
        value: 'Interstate 10 Eastbound, Mile Marker 782, Baytown, TX',
        type: 'string',
        confidence: 0.97,
        status: 'verified',
        grounding: { pageNumber: 1, textExcerpt: 'Location of Accident: Interstate 10 Eastbound, Mile Marker 782, Baytown, TX', confidence: 0.98 }
      },
      {
        key: 'totalClaimAmount',
        label: 'Total Estimated Claim Amount',
        value: '$24,850.00 USD',
        type: 'currency',
        confidence: 0.99,
        status: 'verified',
        isCritical: true,
        grounding: { pageNumber: 2, textExcerpt: 'TOTAL ESTIMATED LOSS: $24,850.00 USD', confidence: 0.99 }
      },
      {
        key: 'deductible',
        label: 'Applicable Deductible',
        value: '$2,500.00 USD',
        type: 'currency',
        confidence: 0.96,
        status: 'verified',
        grounding: { pageNumber: 1, textExcerpt: 'COLLISION DEDUCTIBLE: $2,500.00', confidence: 0.97 }
      },
      {
        key: 'policeReportNumber',
        label: 'Police Report #',
        value: 'TX-BPD-2026-09941 (Baytown PD)',
        type: 'string',
        confidence: 0.98,
        status: 'verified',
        grounding: { pageNumber: 1, textExcerpt: 'Police Report Number: TX-BPD-2026-09941', confidence: 0.98 }
      },
      {
        key: 'subrogation',
        label: 'Subrogation Recovery Potential',
        value: '100% Recoverable (State Farm #SF-991204)',
        type: 'string',
        confidence: 0.95,
        status: 'verified',
        grounding: { pageNumber: 2, textExcerpt: 'Vanguard subrogation potential is deemed 100% recoverable', confidence: 0.96 }
      },
      {
        key: 'fraudRiskScore',
        label: 'SIU Fraud Anomaly Risk',
        value: 'Low (4 / 100)',
        type: 'badge',
        confidence: 0.97,
        status: 'verified',
        grounding: { pageNumber: 2, textExcerpt: 'Fraud score is extremely low (4/100)', confidence: 0.98 }
      }
    ],
    redFlags: [
      {
        id: 'rf-ins-1',
        category: 'Cargo Spoilage',
        severity: 'medium',
        title: 'Refrigerated Pharma Cargo Spoilage ($8,900)',
        description: 'Auxiliary refrigeration power failure caused temp rise above critical threshold for 4 pallets of biologics.',
        clauseExcerpt: 'temperature rose from 34°F to 52°F, spoiling 4 pallets of organic pharmaceutical reagents',
        recommendation: 'Request temperature datalogger telemetry log from Carrier Transicold unit.'
      }
    ],
    verticalData: {
      insurance: {
        policyNumber: 'POL-COMM-892104-TX',
        insuredName: 'Swiftline Intermodal Hauling Corp.',
        insuranceCarrier: 'Vanguard Mutual Commercial Casualty Insurance Co.',
        coverageType: 'Commercial Auto & Motor Truck Cargo',
        policyLimit: 1000000,
        deductible: 2500,
        incidentDate: '2026-09-22',
        incidentLocation: 'I-10 Eastbound MM 782, Baytown, TX',
        claimantName: 'Swiftline Intermodal Hauling Corp. (1st Party)',
        lossDescription: 'Third party hydroplaned and struck tractor steer axle in heavy rain.',
        totalClaimAmount: 24850,
        lineItems: [
          { description: 'Freightliner Steer Axle & Suspension Repair', category: 'Physical Damage', amount: 8450, covered: true },
          { description: 'Replacement Front Bumper & Sensor Assembly', category: 'Physical Damage', amount: 3200, covered: true },
          { description: 'Commercial Heavy Towing & Recovery', category: 'Towing & Storage', amount: 1850, covered: true },
          { description: 'Auxiliary Fuel Tank & Deflector Replacement', category: 'Physical Damage', amount: 2450, covered: true },
          { description: 'Spoiled Pharma Reagent Cargo Lot #PH-2026-09', category: 'Cargo Damage', amount: 8900, covered: true }
        ],
        fraudRiskScore: 4,
        fraudIndicators: ['Dashcam verified', 'Clean 4-year driver history', 'Police report citations match'],
        subrogationPotential: true,
        straightThroughProcessingEligible: true
      }
    },
    workflows: [
      {
        id: 'wf-ins-01',
        workflowName: 'Straight-Through Fast Claim Adjudication',
        status: 'completed',
        startedAt: '2026-09-28T16:16:00Z',
        completedAt: '2026-09-28T16:16:05Z',
        decision: 'auto_approved',
        decisionRationale: 'Clean claim auto-approved for reserve allocation. Subrogation demand package automatically queued for State Farm.',
        steps: [
          { id: 'i1', title: 'Gemini Document Extraction', type: 'extraction', status: 'completed', timestamp: '16:16:01', message: 'Extracted ACORD 80 fields & 5 repair line-items.' },
          { id: 'i2', title: 'SIU Anomaly & Fraud Scoring', type: 'validation', status: 'completed', timestamp: '16:16:02', message: 'Fraud risk scored at 4/100 (Threshold < 25 passes).' },
          { id: 'i3', title: 'Subrogation Docket Dispatch', type: 'rule_evaluation', status: 'completed', timestamp: '16:16:03', message: 'Assigned 100% adverse liability to State Farm claim #SF-991204.' },
          { id: 'i4', title: 'Reserve Allocation & Payee Notice', type: 'dispatch_webhook', status: 'completed', timestamp: '16:16:05', message: 'Initial loss reserve set to $24,850.00 in Guidewire ClaimCenter.', outputPayload: { claimNumber: 'CLM-2026-9041', reserveAmount: 24850, fastTrack: true } }
        ]
      }
    ],
    auditTrail: [
      { timestamp: '2026-09-28 16:15:10', user: 'FNOL Portal Intake', action: 'Loss Notice Uploaded', details: 'ACORD 80 form ingested' },
      { timestamp: '2026-09-28 16:16:00', user: 'Gemini 3.8 Flash', action: 'Claim Line Items Extracted', details: '5 items totaled to $24,850' },
      { timestamp: '2026-09-28 16:16:05', user: 'Auto-Triage Engine', action: 'Approved for Subrogation', details: 'Sent to Guidewire ClaimCenter' }
    ]
  },

  // 3. HEALTHCARE VERTICAL
  {
    id: 'doc-hc-003',
    title: 'Prior Authorization & Clinical Necessity Request (Oncology)',
    filename: 'PriorAuth_CMS_Oncology_EleanorVance.pdf',
    fileSize: '530 KB',
    fileType: 'application/pdf',
    uploadedAt: '2026-09-28T18:00:00Z',
    vertical: 'healthcare',
    documentType: 'Prior Authorization Clinical Request (CMS-1500 Attached)',
    status: 'in_review',
    confidenceScore: 0.97,
    pageCount: 3,
    rawText: `PRIOR AUTHORIZATION MEDICAL NECESSITY REVIEW
FACILITY: Memorial Sloan Oncology & Comprehensive Cancer Center
DEPARTMENT: Outpatient Medical Oncology, Pavilion 4B
DATE OF REQUEST: September 28, 2026 | URGENCY: EXPEDITED (24-Hour Clinical Turnaround)

PATIENT DEMOGRAPHICS & HEALTH PLAN
Patient Legal Name: Eleanor M. Vance
Date of Birth: 04/14/1968 (Age: 58) | Gender: Female
Medical Record Number (MRN): 948-2103-SLOAN
Health Insurance Carrier: BlueCross BlueShield Comprehensive Federal
Subscriber ID: BCB-9941042-01 | Group Number: GRP-77401

REQUESTING PHYSICIAN & TREATMENT FACILITY
Ordering Physician: Dr. Robert S. Alpert, MD, FACP
National Provider Identifier (NPI): 1942859102 | State Medical License: NY-284910
Specialty: Medical Oncology & Hematology
Facility NPI: 1043829104 | Tax ID: 13-8821940
Clinical Coordinator Contact: nurse-triage@sloancancer.org | Direct Tel: (212) 555-0182

DIAGNOSIS (ICD-10-CM CODES)
Primary Diagnosis Code:
- ICD-10 C34.90: Malignant neoplasm of unspecified part of bronchus or lung (Stage IV Non-Small Cell Lung Carcinoma, Adenocarcinoma subtype)
Secondary Diagnosis Codes:
- ICD-10 Z85.118: Personal history of malignant neoplasm of bronchus and lung
- ICD-10 R05.1: Acute cough with hemoptysis
- ICD-10 E87.1: Hypoosmolality and hyponatremia

REQUESTED PROCEDURES & MEDICATIONS (HCPCS / CPT CODES)
1. Medication: KEYTRUDA (Pembrolizumab) 200 mg intravenous infusion
   - HCPCS Code: J9271 (Injection, pembrolizumab, 1 mg) — 200 Units
   - Frequency: Every 3 weeks (21-day cycles), Planned Duration: 6 cycles
2. Administration:
   - CPT 96413: Chemotherapy administration, intravenous infusion technique; up to 1 hour, single or initial substance
   - CPT 96415: Chemotherapy administration, intravenous infusion; each additional hour (1 unit)

CLINICAL HISTORY & MEDICAL NECESSITY JUSTIFICATION
Patient is a 58-year-old female diagnosed with Stage IV metastatic non-small cell lung carcinoma (NSCLC) confirmed by core needle biopsy of the right upper lobe on August 15, 2026.
Molecular and Genomic Pathology Testing:
- PD-L1 Tumor Proportion Score (TPS) expression: 78% (High Expression, cutoff ≥ 50%) via Dako 22C3 IHC pharmDx.
- EGFR mutation analysis: Negative (wild-type for exon 19 deletions and L858R).
- ALK rearrangement via FISH: Negative.
- ROS1 and BRAF V600E: Negative.

NCCN Guidelines Category 1 Recommendation:
First-line monotherapy with Pembrolizumab (Keytruda) is standard of care for metastatic NSCLC with PD-L1 TPS ≥ 50% in the absence of EGFR/ALK genomic alterations (KEYNOTE-024 and KEYNOTE-042 randomized Phase 3 trials).
Previous Therapies Attempted: None (Treatment-naive in metastatic setting).
Clinical Contraindications to alternative cytotoxic platinum-doublet chemotherapy: Patient exhibits mild baseline renal impairment (eGFR 48 mL/min/1.73m²), making high-dose cisplatin therapy unfavorable.

EXPEDITED REVIEW ATTESTATION
I hereby certify under penalty of perjury that applying the standard 72-hour review timeframe could seriously jeopardize the patient's life or health, or ability to regain maximum function, given rapid tumor progression.
Physician Signature: /s/ Dr. Robert S. Alpert, MD | NPI: 1942859102`,
    fields: [
      {
        key: 'patientName',
        label: 'Patient Name',
        value: 'Eleanor M. Vance',
        type: 'string',
        confidence: 0.99,
        status: 'verified',
        grounding: { pageNumber: 1, textExcerpt: 'Patient Legal Name: Eleanor M. Vance', confidence: 0.99 }
      },
      {
        key: 'patientDOB',
        label: 'Date of Birth (Age)',
        value: '1968-04-14 (Age 58)',
        type: 'string',
        confidence: 0.99,
        status: 'verified',
        grounding: { pageNumber: 1, textExcerpt: 'Date of Birth: 04/14/1968 (Age: 58)', confidence: 0.99 }
      },
      {
        key: 'mrn',
        label: 'Medical Record # (MRN)',
        value: '948-2103-SLOAN',
        type: 'string',
        confidence: 0.98,
        status: 'verified',
        grounding: { pageNumber: 1, textExcerpt: 'Medical Record Number (MRN): 948-2103-SLOAN', confidence: 0.98 }
      },
      {
        key: 'orderingProvider',
        label: 'Ordering Physician & NPI',
        value: 'Dr. Robert S. Alpert, MD (NPI: 1942859102)',
        type: 'string',
        confidence: 0.98,
        status: 'verified',
        grounding: { pageNumber: 1, textExcerpt: 'Ordering Physician: Dr. Robert S. Alpert, MD ... NPI: 1942859102', confidence: 0.98 }
      },
      {
        key: 'primaryICD10',
        label: 'Primary ICD-10 Diagnosis',
        value: 'C34.90 - Stage IV Metastatic NSCLC',
        type: 'string',
        confidence: 0.98,
        status: 'verified',
        isCritical: true,
        grounding: { pageNumber: 1, textExcerpt: 'ICD-10 C34.90: Malignant neoplasm of unspecified part of bronchus or lung', confidence: 0.99 }
      },
      {
        key: 'hcpcsDrugCode',
        label: 'Requested Medication & HCPCS',
        value: 'Keytruda (Pembrolizumab) 200mg - HCPCS J9271 (200 Units)',
        type: 'string',
        confidence: 0.97,
        status: 'verified',
        isCritical: true,
        grounding: { pageNumber: 1, textExcerpt: 'HCPCS Code: J9271 (Injection, pembrolizumab, 1 mg) — 200 Units', confidence: 0.98 }
      },
      {
        key: 'biomarkerExpression',
        label: 'Biomarker Validation',
        value: 'PD-L1 TPS: 78% (Cutoff ≥50% Met), EGFR/ALK Negative',
        type: 'string',
        confidence: 0.96,
        status: 'verified',
        grounding: { pageNumber: 2, textExcerpt: 'PD-L1 Tumor Proportion Score (TPS) expression: 78%', confidence: 0.97 }
      },
      {
        key: 'urgencyLevel',
        label: 'Prior Auth Urgency',
        value: 'Expedited Urgent (24-Hour Clinical Turnaround)',
        type: 'badge',
        confidence: 0.99,
        status: 'verified',
        grounding: { pageNumber: 1, textExcerpt: 'URGENCY: EXPEDITED (24-Hour Clinical Turnaround)', confidence: 0.99 }
      }
    ],
    redFlags: [
      {
        id: 'rf-hc-1',
        category: 'High-Cost Biologic',
        severity: 'medium',
        title: 'High-Cost Specialty Oncology Agent',
        description: 'Estimated annual regimen exceeds $175,000. Meets NCCN guidelines; requires mandatory medical director peer review sign-off.',
        clauseExcerpt: 'First-line monotherapy with Pembrolizumab (Keytruda) is standard of care for metastatic NSCLC with PD-L1 TPS ≥ 50%',
        recommendation: 'Verify BlueCross specialty pharmacy network routing before final authorization release.'
      }
    ],
    verticalData: {
      healthcare: {
        patientName: 'Eleanor M. Vance',
        patientDOB: '1968-04-14',
        patientMRN: '948-2103-SLOAN',
        subscriberID: 'BCB-9941042-01',
        orderingProvider: 'Dr. Robert S. Alpert, MD',
        providerNPI: '1942859102',
        facilityName: 'Memorial Sloan Oncology Center',
        encounterDate: '2026-09-28',
        primaryDiagnosis: { code: 'C34.90', description: 'Malignant neoplasm of bronchus or lung, Stage IV NSCLC', billable: true },
        secondaryDiagnoses: [
          { code: 'Z85.118', description: 'Personal history of malignant neoplasm of lung' },
          { code: 'R05.1', description: 'Acute cough with hemoptysis' }
        ],
        procedures: [
          { code: 'J9271', description: 'Pembrolizumab injection, 1mg (200 units)', units: 200, standardPrice: 11400 },
          { code: '96413', description: 'Chemotherapy IV infusion, up to 1 hr', units: 1, standardPrice: 380 },
          { code: '96415', description: 'Chemotherapy IV infusion, additional hr', units: 1, standardPrice: 120 }
        ],
        medications: [
          { drugName: 'Keytruda (Pembrolizumab)', dosage: '200 mg', frequency: 'Q3W (Every 21 days)', route: 'Intravenous' }
        ],
        medicalNecessitySummary: 'Stage IV NSCLC, PD-L1 TPS 78% (exceeds 50% guideline). EGFR/ALK negative. Category 1 NCCN recommendation.',
        priorAuthUrgency: 'Expedited Urgent (24hr)',
        priorAuthApproved: true,
        phiEntitiesRedactedCount: 6
      }
    },
    workflows: [
      {
        id: 'wf-hc-01',
        workflowName: 'Expedited Oncology Prior Authorization Fast-Track',
        status: 'completed',
        startedAt: '2026-09-28T18:01:00Z',
        completedAt: '2026-09-28T18:01:06Z',
        decision: 'billing_cleared',
        decisionRationale: 'Medical necessity substantiated by biomarker pathology (PD-L1 78% >= 50% threshold). Pre-authorized for 6 cycles.',
        steps: [
          { id: 'h1', title: 'CMS-1500 / Clinical Note Ingestion', type: 'extraction', status: 'completed', timestamp: '18:01:01', message: 'Extracted patient demographics, NPI, ICD-10 & HCPCS codes.' },
          { id: 'h2', title: 'HIPAA Safe Harbor PHI Masking Check', type: 'validation', status: 'completed', timestamp: '18:01:02', message: 'Audited 6 PHI identifiers. HIPAA BAA transport active.' },
          { id: 'h3', title: 'NCCN Biomarker Clinical Guideline Cross-Check', type: 'rule_evaluation', status: 'completed', timestamp: '18:01:04', message: 'Biomarker Match Confirmed: PD-L1 TPS 78% meets Keytruda protocol criteria.' },
          { id: 'h4', title: 'FHIR PriorAuthorization Resource Dispatch', type: 'dispatch_webhook', status: 'completed', timestamp: '18:01:06', message: 'Auth #PA-2026-ONC-8812 transmitted to Epic EMR & BCBS EDI 278 gateway.', outputPayload: { fhirAuthId: 'PA-2026-ONC-8812', status: 'approved', approvedCycles: 6 } }
        ]
      }
    ],
    auditTrail: [
      { timestamp: '2026-09-28 18:00:15', user: 'Hospital EHR Integration', action: 'Prior Auth Ingested', details: 'Transmitted from Epic CareConnect' },
      { timestamp: '2026-09-28 18:01:00', user: 'Gemini 3.8 Flash', action: 'ICD-10 & Biomarkers Extracted', details: 'Extracted C34.90, J9271, PD-L1 78%' },
      { timestamp: '2026-09-28 18:01:06', user: 'Clinical Protocol Engine', action: 'Auto-Approved Under Guidelines', details: 'Issued EDI 278 response to BCBS' }
    ]
  },

  // 4. FINANCE & INVOICES VERTICAL
  {
    id: 'doc-fin-004',
    title: 'Enterprise Cloud Infrastructure Vendor Invoice (Datastream Corp)',
    filename: 'Invoice_INV-2026-9812_Datastream.pdf',
    fileSize: '340 KB',
    fileType: 'application/pdf',
    uploadedAt: '2026-09-28T19:20:00Z',
    vertical: 'finance',
    documentType: 'Commercial Tax Invoice & PO Match',
    status: 'extracted',
    confidenceScore: 0.98,
    pageCount: 1,
    rawText: `DATASTREAM HYPERSCALE NETWORKS CORP
TAX INVOICE
Invoice Number: INV-2026-9812
Invoice Date: September 25, 2026 | Payment Due Date: October 25, 2026 (Net 30)
Purchase Order Reference: PO-882104-GLOBAL

VENDOR INFORMATION:
Datastream Hyperscale Networks Corp.
100 Tech Enterprise Blvd, Suite 900, Austin, TX 78701
Federal Tax ID / EIN: 74-9921840 | DUNS: 08-291-8841
Billing Inquiries: accounts-receivable@datastreamcloud.io

BILLED TO CUSTOMER:
Meridian Cloud Systems, Inc.
450 Mission Street, Suite 1800, San Francisco, CA 94105
Attn: Accounts Payable Department (ap-invoices@meridiancloud.io)

ITEMIZED CHARGES:
Item 1: Dedicated NVIDIA H100 GPU Compute Cluster (8 Nodes x 720 Hours)
- SKU: DS-GPU-H100-DED
- Quantity: 5,760 GPU-Hours @ $4.50/hr
- Total: $25,920.00 USD

Item 2: Managed High-Throughput NVMe Block Storage (50 TB SSD Provisioned)
- SKU: DS-STOR-NVME-50T
- Quantity: 1 Month @ $4,800.00/mo
- Total: $4,800.00 USD

Item 3: Dedicated Inter-Region Direct Connect 100 Gbps Transit
- SKU: DS-NET-DC-100G
- Quantity: 1 Month @ $3,500.00/mo
- Total: $3,500.00 USD

Item 4: Enterprise Dedicated Premium SLA & Engineering Technical Support
- SKU: DS-SUPP-ENT-247
- Quantity: 1 Month @ $2,500.00/mo
- Total: $2,500.00 USD

SUBTOTAL: $36,720.00 USD
STATE & LOCAL SALES TAX (Texas 8.25%): $3,029.40 USD
TOTAL INVOICE AMOUNT DUE: $39,749.40 USD

REMITTANCE INSTRUCTIONS:
Bank: Silicon Valley Bank, NA
Routing Transit Number (ABA): 121140399
Account Number: 8820-9941-02
Swift / BIC: SVBUS6SXXX
Wire Reference: INV-2026-9812

3-WAY PO MATCH AUDIT:
PO #PO-882104-GLOBAL matches contracted rates. Line item totals correspond exactly to PO line items 1 through 4. Variance is 0.00%.`,
    fields: [
      {
        key: 'invoiceNumber',
        label: 'Invoice Number',
        value: 'INV-2026-9812',
        type: 'string',
        confidence: 0.99,
        status: 'verified',
        grounding: { pageNumber: 1, textExcerpt: 'Invoice Number: INV-2026-9812', confidence: 0.99 }
      },
      {
        key: 'vendorName',
        label: 'Vendor Name',
        value: 'Datastream Hyperscale Networks Corp.',
        type: 'string',
        confidence: 0.99,
        status: 'verified',
        grounding: { pageNumber: 1, textExcerpt: 'Datastream Hyperscale Networks Corp.', confidence: 0.99 }
      },
      {
        key: 'poNumber',
        label: 'Purchase Order #',
        value: 'PO-882104-GLOBAL',
        type: 'string',
        confidence: 0.98,
        status: 'verified',
        grounding: { pageNumber: 1, textExcerpt: 'Purchase Order Reference: PO-882104-GLOBAL', confidence: 0.98 }
      },
      {
        key: 'totalAmount',
        label: 'Total Amount Due',
        value: '$39,749.40 USD',
        type: 'currency',
        confidence: 0.99,
        status: 'verified',
        isCritical: true,
        grounding: { pageNumber: 1, textExcerpt: 'TOTAL INVOICE AMOUNT DUE: $39,749.40 USD', confidence: 0.99 }
      },
      {
        key: 'taxAmount',
        label: 'Sales Tax (8.25%)',
        value: '$3,029.40 USD',
        type: 'currency',
        confidence: 0.97,
        status: 'verified',
        grounding: { pageNumber: 1, textExcerpt: 'STATE & LOCAL SALES TAX (Texas 8.25%): $3,029.40 USD', confidence: 0.97 }
      },
      {
        key: 'dueDate',
        label: 'Payment Due Date',
        value: '2026-10-25 (Net 30)',
        type: 'date',
        confidence: 0.98,
        status: 'verified',
        grounding: { pageNumber: 1, textExcerpt: 'Payment Due Date: October 25, 2026 (Net 30)', confidence: 0.98 }
      },
      {
        key: 'poMatchStatus',
        label: '3-Way PO Match',
        value: 'Exact Match (0.00% Variance)',
        type: 'badge',
        confidence: 0.99,
        status: 'verified',
        grounding: { pageNumber: 1, textExcerpt: 'PO #PO-882104-GLOBAL matches contracted rates ... Variance is 0.00%', confidence: 0.99 }
      }
    ],
    redFlags: [],
    verticalData: {
      finance: {
        invoiceNumber: 'INV-2026-9812',
        vendorName: 'Datastream Hyperscale Networks Corp.',
        vendorTaxId: '74-9921840',
        vendorAddress: '100 Tech Enterprise Blvd, Suite 900, Austin, TX 78701',
        customerName: 'Meridian Cloud Systems, Inc.',
        purchaseOrderNumber: 'PO-882104-GLOBAL',
        invoiceDate: '2026-09-25',
        dueDate: '2026-10-25',
        paymentTerms: 'Net 30',
        currency: 'USD',
        lineItems: [
          { item: 'Dedicated NVIDIA H100 GPU Compute Cluster', sku: 'DS-GPU-H100-DED', quantity: 5760, unitPrice: 4.50, total: 25920.00 },
          { item: 'Managed NVMe Block Storage (50 TB SSD)', sku: 'DS-STOR-NVME-50T', quantity: 1, unitPrice: 4800.00, total: 4800.00 },
          { item: 'Dedicated Direct Connect 100 Gbps Transit', sku: 'DS-NET-DC-100G', quantity: 1, unitPrice: 3500.00, total: 3500.00 },
          { item: 'Enterprise Dedicated 24/7 Premium SLA Support', sku: 'DS-SUPP-ENT-247', quantity: 1, unitPrice: 2500.00, total: 2500.00 }
        ],
        subtotal: 36720.00,
        taxRatePercent: 8.25,
        taxAmount: 3029.40,
        totalAmount: 39749.40,
        poMatchStatus: 'Exact Match',
        poVarianceAmount: 0.0,
        bankDetails: {
          bankName: 'Silicon Valley Bank, NA',
          routingNumber: '121140399',
          accountLast4: '02',
          iban: 'SVBUS6SXXX'
        }
      }
    },
    workflows: [
      {
        id: 'wf-fin-01',
        workflowName: '3-Way Match & NetSuite ERP Posting',
        status: 'completed',
        startedAt: '2026-09-28T19:21:00Z',
        completedAt: '2026-09-28T19:21:03Z',
        decision: 'auto_approved',
        decisionRationale: 'Exact 3-way match against PO-882104-GLOBAL. Zero variance detected. Scheduled for ACH disbursement on Oct 24, 2026.',
        steps: [
          { id: 'f1', title: 'Invoice Optical & Line Item Extraction', type: 'extraction', status: 'completed', timestamp: '19:21:01', message: 'Extracted 4 line items totaling $39,749.40.' },
          { id: 'f2', title: 'PO-882104 3-Way Cross-Check', type: 'validation', status: 'completed', timestamp: '19:21:02', message: 'Verified SKU pricing and received quantity against warehouse GRN.' },
          { id: 'f3', title: 'Approval Hierarchy Rule', type: 'rule_evaluation', status: 'completed', timestamp: '19:21:02', message: 'Amount $39,749.40 <= $50,000 threshold. Auto-cleared for payment.' },
          { id: 'f4', title: 'NetSuite VendorBill Posting', type: 'dispatch_webhook', status: 'completed', timestamp: '19:21:03', message: 'Posted VendorBill #VB-449102 in NetSuite AP Ledger.', outputPayload: { netSuiteBillId: 'VB-449102', paymentDueDate: '2026-10-25', status: 'APPROVED_FOR_PAYMENT' } }
        ]
      }
    ],
    auditTrail: [
      { timestamp: '2026-09-28 19:20:10', user: 'AP Email Ingestion Bot', action: 'Invoice Attached', details: 'Parsed from ap-invoices@meridiancloud.io' },
      { timestamp: '2026-09-28 19:21:00', user: 'Gemini 3.8 Flash', action: 'Line Item Extraction', details: 'Extracted 4 line items and 8.25% sales tax' },
      { timestamp: '2026-09-28 19:21:03', user: 'ERP Workflow Runner', action: 'NetSuite Bill Created', details: 'Bill #VB-449102 scheduled' }
    ]
  }
];
