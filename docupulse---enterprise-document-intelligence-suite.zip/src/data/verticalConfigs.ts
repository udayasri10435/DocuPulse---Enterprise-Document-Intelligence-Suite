import { VerticalType } from '../types/document';

export interface VerticalConfig {
  id: VerticalType;
  name: string;
  tagline: string;
  description: string;
  badge: string;
  accentColor: string;
  borderColor: string;
  documentTypes: string[];
  extractionFields: {
    key: string;
    label: string;
    description: string;
    required: boolean;
    critical: boolean;
    example: string;
  }[];
  standardWorkflows: {
    id: string;
    name: string;
    trigger: string;
    description: string;
    defaultEnabled: boolean;
    ruleDescription: string;
  }[];
}

export const VERTICAL_CONFIGS: Record<VerticalType, VerticalConfig> = {
  legal: {
    id: 'legal',
    name: 'Legal Intelligence',
    tagline: 'Contract analytics, redline detection & obligation governance',
    description: 'Ingest complex MSAs, NDAs, SaaS licenses, and IP assignments. Extract critical dates, indemnification scope, liability caps, and detect unvetted risks.',
    badge: 'Legal & Risk',
    accentColor: 'text-indigo-400 bg-indigo-500/10 border-indigo-500/30',
    borderColor: 'border-indigo-500/40',
    documentTypes: [
      'Master Services Agreement (MSA)',
      'Non-Disclosure Agreement (NDA)',
      'Software License Agreement (SLA)',
      'Employment & IP Assignment Agreement',
      'Vendor Data Processing Addendum (DPA)'
    ],
    extractionFields: [
      { key: 'contractTitle', label: 'Contract Title', description: 'Formal title of the agreement', required: true, critical: false, example: 'Master Services Agreement' },
      { key: 'parties', label: 'Contracting Parties', description: 'Names and corporate entity types of all signatories', required: true, critical: true, example: 'Meridian Systems Inc. & Apex Logistics LLC' },
      { key: 'effectiveDate', label: 'Effective Date', description: 'Commencement date of legal obligations', required: true, critical: false, example: '2026-10-01' },
      { key: 'terminationDate', label: 'Term / Expiration', description: 'Initial duration or termination date', required: true, critical: false, example: '2029-09-30 (36 Months)' },
      { key: 'governingLaw', label: 'Governing Law & Venue', description: 'State/country jurisdiction for dispute resolution', required: true, critical: true, example: 'State of Delaware, New Castle County' },
      { key: 'liabilityCap', label: 'Liability Cap & Scope', description: 'Aggregate financial liability ceiling or multiplier', required: true, critical: true, example: '$500,000 or 12 months fees' },
      { key: 'indemnificationCarveOut', label: 'Uncapped Liability Carve-Outs', description: 'Exceptions to liability cap (IP infringement, data breach, willful misconduct)', required: true, critical: true, example: 'IP indemnification and privacy breaches uncapped' },
      { key: 'confidentialityPeriod', label: 'Confidentiality Duration', description: 'Years of post-termination confidentiality duty', required: true, critical: false, example: '5 years (Trade secrets perpetual)' },
      { key: 'autoRenewalNotice', label: 'Auto-Renewal Notice Window', description: 'Days required to provide notice of non-renewal', required: true, critical: false, example: '60 days prior to term expiration' }
    ],
    standardWorkflows: [
      {
        id: 'legal-wf-1',
        name: 'General Counsel High-Exposure Escalation',
        trigger: 'Uncapped Liability OR Liability Cap > $500,000 OR Non-Delaware Venue',
        description: 'Halts automated execution and routes redlines to Senior Legal Counsel with an executive summary.',
        defaultEnabled: true,
        ruleDescription: 'If liability cap is uncapped or exceeds $500k, route to General Counsel queue with high priority.'
      },
      {
        id: 'legal-wf-2',
        name: 'Standard Contract Fast-Track & E-Sign Routing',
        trigger: 'Mutual NDA / Low Risk Score <= 20',
        description: 'Auto-generates DocuSign envelope with signer metadata and pre-fills signature tabs.',
        defaultEnabled: true,
        ruleDescription: 'If risk rating is Low and standard governing law matches corporate policy, dispatch DocuSign envelope.'
      },
      {
        id: 'legal-wf-3',
        name: 'Obligation & Auto-Renewal Calendar Sync',
        trigger: 'Auto-Renewal == true',
        description: 'Calculates non-renewal deadlines and schedules automated alert triggers to procurement & legal.',
        defaultEnabled: true,
        ruleDescription: 'Calculates notice cutoff date (Expiration - Notice Window) and posts calendar milestone.'
      }
    ]
  },

  insurance: {
    id: 'insurance',
    name: 'Insurance Intelligence',
    tagline: 'FNOL triage, damage line-item extraction & fraud scoring',
    description: 'Process First Notice of Loss (FNOL), ACORD forms, accident reports, and medical damage claims with straight-through processing eligibility.',
    badge: 'Claims & Triage',
    accentColor: 'text-amber-400 bg-amber-500/10 border-amber-500/30',
    borderColor: 'border-amber-500/40',
    documentTypes: [
      'ACORD 80 Commercial Auto Loss Notice',
      'ACORD 25 Property Damage Loss Notice',
      'Bodily Injury & Medical Treatment Claim',
      'Commercial Cargo Loss & Spoilage Report',
      'Third-Party Subrogation Demand Packet'
    ],
    extractionFields: [
      { key: 'policyNumber', label: 'Policy Number', description: 'Unique carrier policy identifier', required: true, critical: true, example: 'POL-COMM-892104-TX' },
      { key: 'insuredName', label: 'Named Insured', description: 'Primary policyholder corporate or individual entity', required: true, critical: true, example: 'Swiftline Intermodal Hauling Corp.' },
      { key: 'incidentDate', label: 'Date & Time of Loss', description: 'Exact date and time when loss event occurred', required: true, critical: true, example: '2026-09-22 14:45 CST' },
      { key: 'incidentLocation', label: 'Incident Location', description: 'Address, highway mile marker, or geospatial coordinates', required: true, critical: false, example: 'I-10 Eastbound MM 782, Baytown, TX' },
      { key: 'totalClaimAmount', label: 'Total Claim Amount', description: 'Aggregate financial damages claimed across all line items', required: true, critical: true, example: '$24,850.00 USD' },
      { key: 'deductible', label: 'Applicable Deductible', description: 'Policyholder deductible obligation', required: true, critical: false, example: '$2,500.00 USD' },
      { key: 'policeReportNumber', label: 'Police / Agency Report #', description: 'Official law enforcement incident citation number', required: false, critical: false, example: 'TX-BPD-2026-09941' },
      { key: 'fraudRiskScore', label: 'SIU Anomaly / Fraud Score', description: 'Calculated 0-100 anomaly indicator based on narrative and records', required: true, critical: true, example: '4 / 100 (Low)' },
      { key: 'subrogationPotential', label: 'Subrogation Potential', description: 'Potential to recover loss funds from third-party adverse carrier', required: true, critical: false, example: '100% Recoverable (State Farm)' }
    ],
    standardWorkflows: [
      {
        id: 'ins-wf-1',
        name: 'Straight-Through Processing (STP) Auto-Adjudication',
        trigger: 'Claim Amount < $25,000 AND Fraud Score < 15 AND Clear Police Citation',
        description: 'Auto-approves clean claims, allocates reserves in Guidewire ClaimCenter, and notifies claimant.',
        defaultEnabled: true,
        ruleDescription: 'Auto-adjudicates claim and sets initial reserve without requiring manual adjuster touch.'
      },
      {
        id: 'ins-wf-2',
        name: 'Special Investigation Unit (SIU) Fraud Escalation',
        trigger: 'Fraud Score >= 40 OR Prior Claims > 3 OR Telematics Speed Mismatch',
        description: 'Locks claim settlement, extracts dashcam metadata, and dispatches SIU investigator brief.',
        defaultEnabled: true,
        ruleDescription: 'If anomaly indicators are present, place settlement hold and assign to SIU detective.'
      },
      {
        id: 'ins-wf-3',
        name: 'Subrogation Demand Package Generation',
        trigger: 'Subrogation Potential == true AND Third Party Carrier Identified',
        description: 'Assembles ACORD form, police citation, and itemized repair estimates into arbitration packet.',
        defaultEnabled: true,
        ruleDescription: 'Generates inter-insurance subrogation packet and sends to adverse insurer claims portal.'
      }
    ]
  },

  healthcare: {
    id: 'healthcare',
    name: 'Healthcare Intelligence',
    tagline: 'Clinical prior-auth, ICD-10/CPT coding & HIPAA PHI audit',
    description: 'Transform CMS-1500 claims, prior authorizations, EHR progress notes, and pathology reports into verified clinical codes and payer payloads.',
    badge: 'Clinical & Coding',
    accentColor: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30',
    borderColor: 'border-emerald-500/40',
    documentTypes: [
      'Prior Authorization Clinical Necessity Request',
      'CMS-1500 Professional Health Insurance Claim',
      'Hospital Discharge & Clinical Operative Summary',
      'Molecular Pathology & Genomic Biomarker Report',
      'Specialty Pharmacy Infusion Prescription'
    ],
    extractionFields: [
      { key: 'patientName', label: 'Patient Name & MRN', description: 'Patient legal name and medical record number', required: true, critical: true, example: 'Eleanor M. Vance (MRN 948-2103)' },
      { key: 'patientDOB', label: 'Date of Birth (Age)', description: 'Patient date of birth and calculated age', required: true, critical: false, example: '1968-04-14 (Age 58)' },
      { key: 'orderingProvider', label: 'Ordering Provider & NPI', description: 'Treating clinician and 10-digit National Provider Identifier', required: true, critical: true, example: 'Dr. Robert S. Alpert, MD (NPI 1942859102)' },
      { key: 'primaryICD10', label: 'Primary Diagnosis (ICD-10)', description: 'Primary billable diagnosis code with clinical descriptor', required: true, critical: true, example: 'C34.90 - Metastatic NSCLC' },
      { key: 'hcpcsDrugCode', label: 'Requested Medication / CPT', description: 'HCPCS J-code, CPT procedure codes, and administration units', required: true, critical: true, example: 'Keytruda (HCPCS J9271, 200 Units)' },
      { key: 'biomarkerValidation', label: 'Biomarker / Lab Pathology', description: 'Lab criteria required by payer medical necessity policy', required: true, critical: true, example: 'PD-L1 TPS: 78% (Cutoff >= 50%)' },
      { key: 'urgencyLevel', label: 'Prior Auth Urgency', description: 'Payer turnaround urgency (Standard 72hr vs Expedited 24hr)', required: true, critical: false, example: 'Expedited Urgent (24-Hour Clinical)' },
      { key: 'phiCount', label: 'HIPAA PHI Identifiers', description: 'Count of Protected Health Information entities detected and secured', required: true, critical: false, example: '6 PHI entities audited' }
    ],
    standardWorkflows: [
      {
        id: 'hc-wf-1',
        name: 'Expedited Oncology Prior Authorization Fast-Track',
        trigger: 'Urgency == Expedited AND Biomarker Threshold Met',
        description: 'Auto-validates NCCN category 1 guidelines and issues FHIR PriorAuthorization approval.',
        defaultEnabled: true,
        ruleDescription: 'Matches ICD-10 and biomarker criteria against clinical clinical pathways for instantaneous authorization.'
      },
      {
        id: 'hc-wf-2',
        name: 'Pre-Billing ICD-10 & CPT Cross-Walk Scrub',
        trigger: 'All CMS-1500 / Clinical Claims',
        description: 'Verifies NCCI edits, modifier requirements, and billable specificity before payer transmission.',
        defaultEnabled: true,
        ruleDescription: 'Detects unbundled CPT codes and missing diagnosis pointers to prevent 98% of payer rejections.'
      },
      {
        id: 'hc-wf-3',
        name: 'HIPAA PHI Redaction & Research De-Identification',
        trigger: 'Export for Secondary Research / External Review',
        description: 'Applies Safe Harbor method de-identification to patient names, dates, and account numbers.',
        defaultEnabled: true,
        ruleDescription: 'Redacts 18 HIPAA identifiers while preserving clinical terms for secondary analysis.'
      }
    ]
  },

  finance: {
    id: 'finance',
    name: 'Finance & Invoices',
    tagline: '3-way PO match, line-item extraction & ERP ledger posting',
    description: 'Extract multi-line vendor invoices, receipts, and procurement purchase orders. Automate variance checks, tax calculations, and NetSuite/SAP sync.',
    badge: 'AP & Invoices',
    accentColor: 'text-cyan-400 bg-cyan-500/10 border-cyan-500/30',
    borderColor: 'border-cyan-500/40',
    documentTypes: [
      'Commercial Vendor Tax Invoice',
      'Enterprise Purchase Order (PO)',
      'Warehouse Goods Receipt Note (GRN)',
      'Corporate Travel & Expense Receipt',
      'IRS Form W-9 / Vendor Tax Certificate'
    ],
    extractionFields: [
      { key: 'invoiceNumber', label: 'Invoice Number', description: 'Vendor assigned invoice number', required: true, critical: true, example: 'INV-2026-9812' },
      { key: 'vendorName', label: 'Vendor Name & Tax ID', description: 'Legal vendor corporate name and EIN/TIN', required: true, critical: true, example: 'Datastream Hyperscale Corp (EIN 74-9921840)' },
      { key: 'poNumber', label: 'Purchase Order #', description: 'Associated customer purchase order reference', required: true, critical: true, example: 'PO-882104-GLOBAL' },
      { key: 'totalAmount', label: 'Total Amount Due', description: 'Grand total payable including taxes and shipping', required: true, critical: true, example: '$39,749.40 USD' },
      { key: 'taxAmount', label: 'Tax Rate & Amount', description: 'Calculated state/VAT taxes and percentage rate', required: true, critical: false, example: '8.25% ($3,029.40 USD)' },
      { key: 'dueDate', label: 'Payment Due Date', description: 'Maturity date based on agreed payment terms', required: true, critical: false, example: '2026-10-25 (Net 30)' },
      { key: 'poMatchStatus', label: '3-Way PO Match Status', description: 'Variance audit between PO, GRN receipt, and invoice', required: true, critical: true, example: 'Exact Match (0.00% Variance)' }
    ],
    standardWorkflows: [
      {
        id: 'fin-wf-1',
        name: '3-Way PO Match & NetSuite AP Ledger Posting',
        trigger: 'PO Variance == 0% AND Amount <= $50,000',
        description: 'Auto-posts verified invoice to NetSuite ERP as an approved VendorBill for scheduled ACH disbursement.',
        defaultEnabled: true,
        ruleDescription: 'If line-item prices match purchase order within $0.00 tolerance, post to ERP AP ledger automatically.'
      },
      {
        id: 'fin-wf-2',
        name: 'High-Value Invoice VP Sign-Off Exception',
        trigger: 'Invoice Total > $50,000 OR Price Variance > 2%',
        description: 'Routes invoice to VP of Finance and Procurement Director with side-by-side line item variance analysis.',
        defaultEnabled: true,
        ruleDescription: 'Holds payment and generates Slack/Email approval link for financial controller.'
      }
    ]
  }
};
