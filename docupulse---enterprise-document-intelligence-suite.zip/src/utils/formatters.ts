export function formatCurrency(amount: number, currency = 'USD'): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency,
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount);
}

export function formatDate(dateString: string): string {
  try {
    const d = new Date(dateString);
    if (isNaN(d.getTime())) return dateString;
    return d.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  } catch {
    return dateString;
  }
}

export function formatDateTime(dateString: string): string {
  try {
    const d = new Date(dateString);
    if (isNaN(d.getTime())) return dateString;
    return d.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return dateString;
  }
}

export function getConfidenceColor(score: number): { text: string; bg: string; border: string } {
  if (score >= 0.92) {
    return { text: 'text-emerald-400', bg: 'bg-emerald-500/10', border: 'border-emerald-500/30' };
  }
  if (score >= 0.80) {
    return { text: 'text-amber-400', bg: 'bg-amber-500/10', border: 'border-amber-500/30' };
  }
  return { text: 'text-rose-400', bg: 'bg-rose-500/10', border: 'border-rose-500/30' };
}

export function getSeverityBadge(severity: 'low' | 'medium' | 'high' | 'critical'): {
  text: string;
  bg: string;
  border: string;
  label: string;
} {
  switch (severity) {
    case 'critical':
      return { text: 'text-rose-400', bg: 'bg-rose-500/10', border: 'border-rose-500/30', label: 'Critical Risk' };
    case 'high':
      return { text: 'text-orange-400', bg: 'bg-orange-500/10', border: 'border-orange-500/30', label: 'High Exposure' };
    case 'medium':
      return { text: 'text-amber-400', bg: 'bg-amber-500/10', border: 'border-amber-500/30', label: 'Moderate' };
    case 'low':
    default:
      return { text: 'text-blue-400', bg: 'bg-blue-500/10', border: 'border-blue-500/30', label: 'Informational' };
  }
}
